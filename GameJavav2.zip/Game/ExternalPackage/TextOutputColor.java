package Game.ExternalPackage;

import Game.GamePack.*;

public class TextOutputColor extends Game {

	private String RED;
	private String BLUE;
	private String Etc;

}