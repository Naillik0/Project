package Game.SpaceShipPack;

public class Lazer extends Weapons {

	public Lazer() {
		// TODO - implement Lazer.Lazer
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param other
	 */
	public void useW(Player other) {

	}

}