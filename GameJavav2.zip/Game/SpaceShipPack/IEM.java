package Game.SpaceShipPack;

public class IEM extends Weapons {

	public IEM() {
		// TODO - implement IEM.IEM
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param other
	 */
	public void useW(Player other) {

	}

}