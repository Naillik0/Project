package Game.SpaceShipPack;

public class Blaster extends Weapons {

	public Blaster() {
		// TODO - implement Blaster.Blaster
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param other
	 */
	public void useW(Player other) {

	}

}