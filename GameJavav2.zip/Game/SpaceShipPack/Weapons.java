package Game.SpaceShipPack;

import Game.ZoneIteractionsPack.*;

public abstract class Weapons extends Items {

	private final String NAME;
	private final int DAMAGE;
	private int Rank;
	private boolean UseAmmo;

	public Weapons() {
		// TODO - implement Weapons.Weapons
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param other
	 */
	public void useW(Player other) {

	}

	public boolean canShoot() {
		// TODO - implement Weapons.canShoot
		throw new UnsupportedOperationException();
	}

	public void upRank() {
		// TODO - implement Weapons.upRank
		throw new UnsupportedOperationException();
	}

	public boolean haveAmmo() {
		// TODO - implement Weapons.haveAmmo
		throw new UnsupportedOperationException();
	}

}