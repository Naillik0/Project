package Game.SpaceShipPack;

public class BlasterUltime extends Weapons {

	public BlasterUltime() {
		// TODO - implement BlasterUltime.BlasterUltime
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param other
	 */
	public void useW(Player other) {

	}

}