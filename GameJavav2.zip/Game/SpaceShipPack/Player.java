package Game.SpaceShipPack;

import java.util.*;
import Game.ZoneIteractionsPack.*;

public class Player {

	private String Name;
	private int LifePoint;
	private int LIFEPOINTMAX;
	private int Rank;
	private Collection<Weapons> tabEquipedWeapons;
	private boolean IsFrendly;
	private Shield myShield;
	private Place myPlace;
	private Collection<Items> Inventory;

	/**
	 * 
	 * @param name
	 * @param lifepoint
	 */
	public void SpaceShip(String name, int lifepoint) {

	}

	public void getHit() {
		// TODO - implement SpaceShip.getHit
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Weapon
	 * @param enemi
	 */
	public void UseWeapon(Weapons Weapon, Player enemi) {

	}

	public boolean is_destroy() {
		// TODO - implement SpaceShip.is_destroy
		throw new UnsupportedOperationException();
	}

	public void upRank() {
		// TODO - implement SpaceShip.upRank
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param this_item
	 */
	public void UseThisItems(Items this_item) {
		// TODO - implement SpaceShip.UseThisItems
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisWeapon
	 * @param position
	 */
	public void EquipWeapon(Weapons thisWeapon, int position) {
		// TODO - implement SpaceShip.EquipWeapon
		throw new UnsupportedOperationException();
	}

}