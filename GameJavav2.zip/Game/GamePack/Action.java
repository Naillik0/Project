package Game.GamePack;

public enum Action {
	USE(3,"USE"),
	GO(0,"GO"),
	LOOK(1,"LOOK"),
	TAKE(2,"TAKE"),
	HELP(4,"HELP"),
	ATTACK(5,"ATTACK"),
	QUIT(10,"QUIT")
}