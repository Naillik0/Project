package Game.GamePack;

public enum GameState {
	Start,
	Selection,
	Option,
	Battle,
	Area,
	Shop
}