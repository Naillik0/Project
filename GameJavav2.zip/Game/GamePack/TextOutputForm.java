package Game.GamePack;

public class TextOutputForm {

	private int SIZEOFSCREEN;
	private int SIZEOFMAP;

	public TextOutputForm() {
		// TODO - implement TextOutputForm.TextOutputForm
		throw new UnsupportedOperationException();
	}

	public void PrintText() {
		// TODO - implement TextOutputForm.PrintText
		throw new UnsupportedOperationException();
	}

	public void PrintTitle() {
		// TODO - implement TextOutputForm.PrintTitle
		throw new UnsupportedOperationException();
	}

	public void PrintCharPicture() {
		// TODO - implement TextOutputForm.PrintCharPicture
		throw new UnsupportedOperationException();
	}

	public void PrintUDLigne() {
		// TODO - implement TextOutputForm.PrintUDLigne
		throw new UnsupportedOperationException();
	}

	public void PrintMidLigne() {
		// TODO - implement TextOutputForm.PrintMidLigne
		throw new UnsupportedOperationException();
	}

	public void PrintActions() {
		// TODO - implement TextOutputForm.PrintActions
		throw new UnsupportedOperationException();
	}

}