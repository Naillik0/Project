package Game.ZoneIteractionsPack;

import Game.SpaceShipPack.*;

public class RepairKit extends Items {

	public RepairKit() {
		// TODO - implement RepairKit.RepairKit
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisPlayer
	 */
	public void UseObjectOn(Player thisPlayer) {
		// TODO - implement RepairKit.UseObjectOn
		throw new UnsupportedOperationException();
	}

}