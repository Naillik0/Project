package Game.ZoneIteractionsPack;

import java.util.*;
import Game.SpaceShipPack.*;

public class Place {

	private final String NAME_LOCATION;
	private final String DESCRIPTION;
	private Collection<Exit> ListOfExit;
	private Collection<Items> ListOfItems;
	private Collection<Player> ListOfPLayer;

	public String getName() {
		// TODO - implement Place.getName
		throw new UnsupportedOperationException();
	}

	public String getDescription() {
		// TODO - implement Place.getDescription
		throw new UnsupportedOperationException();
	}

}