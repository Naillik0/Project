package Game.ZoneIteractionsPack;

import Game.SpaceShipPack.*;

public class Ammo extends Items {

	private String UseWithThisWeapon;

	public Ammo() {
		// TODO - implement Ammo.Ammo
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisPlayer
	 */
	public void UseObjectOn(Player thisPlayer) {
		// TODO - implement Ammo.UseObjectOn
		throw new UnsupportedOperationException();
	}

}