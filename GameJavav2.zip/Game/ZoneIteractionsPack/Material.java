package Game.ZoneIteractionsPack;

import Game.SpaceShipPack.*;

public class Material extends Items {

	public Material() {
		// TODO - implement Material.Material
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisPlayer
	 */
	public void UseObjectOn(Player thisPlayer) {
		// TODO - implement Material.UseObjectOn
		throw new UnsupportedOperationException();
	}

}