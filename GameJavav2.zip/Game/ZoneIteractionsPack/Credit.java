package Game.ZoneIteractionsPack;

import Game.SpaceShipPack.*;

public class Credit extends Items {

	public Credit() {
		// TODO - implement Credit.Credit
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisPlayer
	 */
	public void UseObjectOn(Player thisPlayer) {
		// TODO - implement Credit.UseObjectOn
		throw new UnsupportedOperationException();
	}

}