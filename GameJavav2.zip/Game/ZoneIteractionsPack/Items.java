package Game.ZoneIteractionsPack;

import Game.SpaceShipPack.*;

public abstract class Items {

	private String NAME;
	private int Quantity;
	private int Price;

	/**
	 * 
	 * @param thisPlayer
	 */
	public abstract void UseObjectOn(Player thisPlayer);

}