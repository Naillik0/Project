package Game.ZoneIteractionsPack;

public class Exit {

	private int Distance;
	private Place[] LinkBetweenPlace;

	public Place getOtherPlace() {
		// TODO - implement Exit.getOtherPlace
		throw new UnsupportedOperationException();
	}

	public void getDistance() {
		// TODO - implement Exit.getDistance
		throw new UnsupportedOperationException();
	}

}