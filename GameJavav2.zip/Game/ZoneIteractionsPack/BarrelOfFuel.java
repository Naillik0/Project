package Game.ZoneIteractionsPack;

import Game.SpaceShipPack.*;

public class BarrelOfFuel extends Items {

	/**
	 * 
	 * @param thisPlayer
	 */
	public void UseObjectOn(Player thisPlayer) {

	}

	public BarrelOfFuel() {
		// TODO - implement BarrelOfFuel.BarrelOfFuel
		throw new UnsupportedOperationException();
	}

}