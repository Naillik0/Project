package ToInfinityAndBeyond.SpacialPackage;

import ToInfinityAndBeyond.GameControlPackage.*;
import ToInfinityAndBeyond.ZoneIteractionsPackage.*;
import java.util.HashMap;
import java.util.Scanner;


public class Player extends SpacialObject implements Shoot {

	private int repairKitUsed;
	private int placeDiscover;
	private final TextOutputForm tof;
        private final static int priceUpgrade = 300;
        private int totalDamageTaken;

        
        public Player(String name, int hp, int rank, HashMap<Integer, Weapons> tabWeapons, Storage inventory, Shield shield, int _fuelMeter,TextOutputForm _tof) {
            super(name, hp, rank, tabWeapons, inventory, shield, _fuelMeter);
            this.tof=_tof;
            this.totalDamageTaken = 0;
            this.placeDiscover = 0;
            this.repairKitUsed = 0;
        }

	public void upRank() {
            if(this.getRank() < 2){
                HashMap<String,Items> Liste = this.getMyStorage().getListItems();
                Items money = Liste.get("Credit");
                if(money.getQuantity() < priceUpgrade){
                tof.printLineText("Not enought money to upgrage your Spaceship");
                }
                else{
                    tof.printLineText("Your Spaceship is level 2");
                    this.setRank(2); 
                    this.setMax_hp(40);
                    money.delQuantity(money.getQuantity()-priceUpgrade);
                }
            }
            else{
                tof.printLineText("Your SpaceShip is already lvl max !"); 
                
            }
	}

	public void UseThisItems(Items this_item) {
            
                HashMap<String,Items> liste = this.getMyStorage().getListItems();
                this_item.useItemOn(this);
                this_item.delQuantity(1);
                liste.replace(this_item.getName(), this_item);
                this.getMyStorage().refresh(liste);
                if("ToolKit".equals(this_item.getName()))
                    repairKitUsed ++;
                if(this_item.getQuantity() == 0)
                    liste.remove(this_item.getName(), this_item);
        }

	
	public boolean haveThisItem(String thisItem){ 
            HashMap<String,Items> liste = this.getMyStorage().getListItems();
            return liste.containsKey(thisItem);
	}

	public void itemInStockage() {
            tof.printLineText("In your storage you have : ");
            HashMap<String,Items> liste = this.getMyStorage().getListItems();
            liste.entrySet().stream().forEach((entrySet) -> {
                String key = entrySet.getKey();
                Items value = entrySet.getValue();
                tof.printLineText("     -"+ value.getQuantity() + " " + key);
            });
           
                   
        }

        public void equipWeapon(Weapons w){
            
            if(this.getMapEquipedWeapons().size() < 2){   //Deux armes max mais on peut facilement augmenter la taille.
                this.getMapEquipedWeapons().put((this.getMapEquipedWeapons().size() + 1), w);
            }
            else{
                Scanner scan = new Scanner(System.in);
                for(int i = 1; i < this.getMapEquipedWeapons().size(); i++){
                    tof.printLineText(i + "You have :" + this.getMapEquipedWeapons().get(i).getName()); 

                }
                int answer = scan.nextInt();
                while(answer != 1 || answer != 2){
                tof.printLineText("Wich weapon want-you to unequip ? "); 
                answer = scan.nextInt();
                }
                this.getMapEquipedWeapons().remove(answer);
                this.getMapEquipedWeapons().put(answer, w);
            }
    }

	public void unequipWeapons() {
            Scanner scan = new Scanner(System.in);
            for(int i = 1; i < this.getMapEquipedWeapons().size(); i++){
                tof.printLineText(i + "You have :" + this.getMapEquipedWeapons().get(i).getName());

            }
            int answer = scan.nextInt();
            while(answer != 1 || answer != 2){
            tof.printLineText("Wich weapon want-you to unequip ? "); //inteface
            answer = scan.nextInt();
            }
            this.getMapEquipedWeapons().remove(answer); 
            }

	public Weapons selectWeapon() {
            Scanner scan = new Scanner(System.in);
            for(int i = 1; i < getMapEquipedWeapons().size(); i++){
                tof.printLineText(i + "You have :" + getMapEquipedWeapons().get(i).getName()); 

            }
            int answer;
            answer = 0;
            while(answer != 1 || answer != 2){
            tof.printLineText("Wich weapon do-you want to use ? "); 
            answer = scan.nextInt();
            }
            return getMapEquipedWeapons().get(answer);
            
	}

        @Override
        public void getHit(int damage,int damageShield,int damageOnHp){
            this.totalDamageTaken += damage;
            super.getHit(damage,damageShield,damageOnHp);
        }

        
	public int getCredit() {
            return this.getMyStorage().getListItems().get("Credit").getQuantity();
	}

	public int getAllDamage() {
            return this.totalDamageTaken;
	}

	public int getNumberRepairKit() {
            return this.repairKitUsed;
	
	}

	public int getNumberPlaceDiscover() {
            return this.placeDiscover;
	}

	
        @Override
	public void useWeapon(Weapons thisWeapon, SpacialObject enemy) {
            if(!enemy.is_destroy()){
            thisWeapon.useItemOn(enemy);
            }
            else
                tof.printLineText("The target is already destroy !");
            }

	public boolean isOutOfFuel() {
            return super.getFuelMeter() == 0 && !(this.getMyStorage().getListItems().containsKey("BarrelOfFuel"));
            }
            
            
	

	public void doAction(String strAction) throws CloneNotSupportedException {
            Scanner scan = new Scanner(System.in);
            HashMap <String,Items> MapItems = this.getMyPlace().getListOfItems();
            
            
            
            
            Action thisAction = Action.HELP;
            for (Action val : Action.values()) {
                if(val.name().equalsIgnoreCase(strAction))thisAction = val;
            }
            
            
        switch(thisAction){
            case GO:
                String answer;
                HashMap <String,Exit> MapOfExit = this.getMyPlace().getMapofExit();
                tof.printLineText("There is "+ MapOfExit.size() + "exits : ");
                MapOfExit.entrySet().stream().forEach((entrySet) -> {
                    String key = entrySet.getKey();
                    Exit value = entrySet.getValue();
                    tof.printLineText("     " + key + "(cost " + MapOfExit.get(key).getDistance() + " fuels )");
                });
                tof.printLineText("     cancel");
                tof.printLineText("Wich place do-you want to go ? ");
                answer = scan.nextLine();
                while((!MapOfExit.containsKey(answer)) || (this.getFuelMeter() < MapOfExit.get(answer).getDistance()) || "cancel".equalsIgnoreCase(answer)) {
                    if (!MapOfExit.containsKey(answer) ){
                        if("cancel".equalsIgnoreCase(answer))
                            break;
                        else
                            tof.printLineText("The name is incorrect");
                    }
                    else{
                        tof.printLineText("You don't have enougth fuels. Try to use some barrelsOfFuels after 'cancel' your jump.");
                        break;
                    }
                    answer = scan.nextLine();

                }
                if((!"cancel".equalsIgnoreCase(answer)) && !(this.getFuelMeter() < MapOfExit.get(answer).getDistance() )){
                    this.setMyPlace(this.getMyPlace().goExit(answer));
                    this.delFuel(MapOfExit.get(answer).getDistance());
                    this.placeDiscover ++;
                }
                break;
            
            case USE:
                Scanner scanIventory = new Scanner(System.in);
                tof.printLineText("Which item do-you want to use ?");
                this.itemInStockage();
                tof.printLineText("     -nothing");
                String itemToUse = scanIventory.nextLine();
                while(!this.haveThisItem(itemToUse) && !"nothing".equals(itemToUse)){
                    tof.printLineText("You don't have this item ! Try another item or nothing. ");
                    itemToUse = scanIventory.nextLine();
                }
                if(!"nothing".equals(itemToUse)){
                    if(this.getMyStorage().getListItems().get(itemToUse).isIsUsable())
                        this.UseThisItems(this.getMyStorage().getListItems().get(itemToUse));
                    else
                        tof.printLineText("You do nothing.");
                }
                
                break;
                
            case LOOK: 
                tof.printLineText("There is : ");
                HashMap <String,Items> mapItems = this.getMyPlace().getListOfItems();
                mapItems.entrySet().stream().forEach((entrySet) -> {
                    String key = entrySet.getKey();
                    Items value = entrySet.getValue();
                    tof.printLineText("     -" +value.getQuantity()+ " " + key);
            });
                break; 
                
            case TAKE:
                
                tof.printLineText("Wich item do-you want to take ?");
                String answer2;
                answer2 = scan.nextLine();
                while(!(this.getMyPlace().getListOfItems().containsKey(answer2)) && !"nothing".equals(answer2)){
                    tof.printLineText("This items isn't in the place. Try another solution or try 'nothing' !");
                    answer2 = scan.nextLine();
                }
                if(!"nothing".equals(answer2)){
                    Items item = this.getMyPlace().removeItem(answer2);
                    if(this.getMyStorage().getListItems().containsKey(item.getName()))
                        this.getMyStorage().getListItems().get(item.getName()).addQuatity(item.getQuantity());
                    else
                    this.getMyStorage().addItem(item);
                }       
                break;
                
                
            case ATTACK:
                Scanner scanTarget = new Scanner(System.in);
                Weapons weapon;
                SpacialObject target;
                HashMap <String,Enemy> ListOftargets = this.getMyPlace().getListOfSO();
                if(ListOftargets.isEmpty()){
                    tof.printLineText("There is on enemy.");
                    break;
                }
                ListOftargets.entrySet().stream().map((entrySet) -> {
                    String key = entrySet.getKey();
                    tof.printLineText("     -"+key);
                return key;
            });
               
                tof.printLineText("Write a name target on this list or nothing :");
                String targetName = scanTarget.nextLine();
                while(!ListOftargets.containsKey(targetName) && (!"nothing".equals(targetName))){
                    tof.printLineText("The target is incorrect ! Enter a valid name or nothing");
                    targetName = scanTarget.nextLine();
                }
                if(!"nothing".equals(targetName)){
                    target = ListOftargets.get(targetName);
                    weapon = this.selectWeapon();
                    this.useWeapon(weapon, target);
                }
                break;
                
                
            case DROP: 
                
                
                tof.printLineText("Wich item do-you want to drop ?");
                this.itemInStockage();
                String answer3;
                answer3 = scan.nextLine();
                while(!(this.getMyStorage().getListItems().containsKey(answer3)) && !"nothing".equals(answer3)){
                    tof.printLineText("This items isn't in the storage. Try another solution !");
                    answer3 = scan.nextLine();
                }
                if(!"nothing".equals(answer3)){
                    int nbOfDrop;
                    Items item2 = this.getMyStorage().getListItems().get(answer3);
                    Scanner scanNbOfDrop = new Scanner(System.in);
                    tof.printLineText("How many do-you want to drop ?");
                    nbOfDrop = scanNbOfDrop.nextInt();
                    while(nbOfDrop > item2.getQuantity()){
                        tof.printLineText("The number is incorrect !");
                        nbOfDrop = scanNbOfDrop.nextInt();
                    }
                    if(nbOfDrop == item2.getQuantity()){
                        this.getMyStorage().getListItems().remove(item2.getName());
                        this.getMyPlace().addItem(item2); 
                    }
                    else{
                        this.getMyStorage().getListItems().get(item2.getName()).delQuantity(nbOfDrop);
                        Items itemtmp = (Items) this.getMyStorage().getListItems().get(item2.getName()).clone();
                        itemtmp.setQuantity(nbOfDrop);
                        this.getMyPlace().addItem(itemtmp);
                    }
                }      
                break;
                
            case HELP: 
                tof.printLineText("Fiche d'aide : ");
                tof.printLineMid();
                tof.printLineText("Command GO :      Allow  the player to go to another place ");
                tof.printLineText("Command USE :     To use a item but not a weapon");
                tof.printLineText("Command LOOK :    Show items on the place");
                tof.printLineText("Command TAKE :    Take an item on the map");
                tof.printLineText("Command ATTACK :  Shoot on a spatial object whith one of your weapon");
                tof.printLineText("Command QUIT :    Quit the game");
                tof.printLineText("Command DROP :    Drop an item on your current place");
                tof.printLineText("Command UPGRADE : Upgrade your ship to have more hp");
                tof.printLineMid();
                
                break;
                
            case UPGRADE:
                this.upRank();
                break;
              
            default : 
                System.out.println("");
                break;
                
            }
        }

}