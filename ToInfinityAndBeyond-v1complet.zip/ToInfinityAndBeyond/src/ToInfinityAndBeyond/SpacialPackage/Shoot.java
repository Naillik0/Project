package ToInfinityAndBeyond.SpacialPackage;

public interface Shoot {

	/**
	 * 
	 * @param thisWeapon
	 * @param _SO
	 */
	abstract void useWeapon(Weapons thisWeapon, SpacialObject _SO);

}