package ToInfinityAndBeyond.ZoneIteractionsPackage;

import ToInfinityAndBeyond.SpacialPackage.*;

public class BarrelOfFuel extends Items {
    
    private static final int PRICE = 10;
    private final static String NAME = "BarelOfFuel";
    private final static int NBFUEL = 5;
    private static final boolean isUsable = false;

    public BarrelOfFuel(int _quantity) {
        super(NAME, _quantity,PRICE,isUsable);
    }

    @Override
    public void useItemOn(SpacialObject thisPlayer) {
        thisPlayer.addFuel(NBFUEL);
    }

}