package ToInfinityAndBeyond.GameControlPackage;

//Alt + Shift + F auto indent
import static ToInfinityAndBeyond.GameControlPackage.GameState.Start;
import java.util.*;
import ToInfinityAndBeyond.SpacialPackage.*;
import ToInfinityAndBeyond.ZoneIteractionsPackage.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;

public class Game {

    private GameState State = Start;
    private ArrayList<File> ListSaveFiles = new ArrayList<>();
    private ArrayList<ArrayList<Place>> ListPlace = new ArrayList<>();
    private Player myPlayer;
    private final String[] FNAME = {"Planet", "Zone", "Asteroid", "Satellite", "Moon"};
    private final String[] FNAMEFORM = {"  O  ", "  *  ", "  °  ", " -o- ", "  C  "};
    private int sizeOfMap = 0;
    private final static String FILE_TYPE = ".ftl";
    private final static String FILE_SEP = System.getProperty("file.separator");

    public Game() throws InterruptedException, IOException, CloneNotSupportedException {
        // TODO - implement Game.Game
        TextOutputForm tof = new TextOutputForm();//Object afficheur

        Scanner scan = new Scanner(System.in);//cration du scanner

        String answer = null; // mémorisation de la réponse
        //Listing des actions
        ArrayList<String> listAction = new ArrayList<>();
        for (Action val : Action.values()) {
            listAction.add(val.name());
        }

        do {

            if (myPlayer != null && myPlayer.is_destroy()) {
                this.State = GameState.GameOver;
            }

            switch (this.State) {
                //----------------------------------------------------------------------------------------------------------
                case Start:

                    tof.printLineText("Conseil : Aggrandiser la console pour mieux voir graphiqement le jeu");
                    tof.printLineText("(Appuyer sur une touche pour continuer)");
                    System.in.read();//waitinput
                    tof.printFormText(tof.getForm("intro"));
                    tof.printLineMid();
                    //Thread.sleep(1000);
                    tof.printFormText(tof.getForm("splashScreen"));
                    tof.printLineMid();
                    //Thread.sleep(2000);
                    tof.printFormText(tof.getForm("outro"));

                    tof.printLineMid();

                    System.in.read();//waitinput
                    tof.printFormText("This game is a Sci-Fi adventure in space.\n"
                            + "You will travel in different place to find elements to collect.\n"
                            + "you can also, upgrade your ship,attack object or enemy...\n"
                            + "Try to do and find a maximum of things and get a bigger highScore.\n"
                            + "Use at any time the command HELP and MAP, if you are lost.\n"
                            + "It will help you for playing the game.\n"
                            + "Good luck.");

                    tof.printLineMid();
                    Thread.sleep(1000);
                    tof.printLineText("Do you want to begin a new game or select a game saved");
                    tof.printLineText("(Enter NEW or SEL to begin)");
                    answer = scan.nextLine();//if(st == null)throw new NullPointerException();
                    if (answer == null) {
                        throw new NullPointerException();
                    }
                    /*Verification */
                    while (!"NEW".equalsIgnoreCase(answer) && !"SEL".equalsIgnoreCase(answer)) {
                        tof.printLineText("Action not reconize");
                        answer = scan.nextLine();
                    }

                    //Selon la réponse
                    if ("NEW".equalsIgnoreCase(answer)) {
                        this.State = GameState.New; //Generate new map player ...
                    } else {
                        tof.printLineText("Loading list of save :");
                        listAllSave();

                        if (this.ListSaveFiles.isEmpty()) {
                            tof.printLineText("No save find");
                            tof.printLineText("Generating a new game...");
                            this.State = GameState.New;
                        } else {
                            this.State = GameState.Selection; //Get in game
                        }
                    }
                    break;
                case New:

                    //new list
                    ListPlace = new ArrayList<>();

                    //generateMap
                    tof.printLineText("Enter the size of the map");
                    tof.printLineText("(SMALL, MEDIUM or BIG)");
                    answer = scan.nextLine();
                    while (!"SMALL".equalsIgnoreCase(answer) && !"MEDIUM".equalsIgnoreCase(answer) && !"BIG".equalsIgnoreCase(answer)) {
                        tof.printLineText("Command unvalide ");
                        answer = scan.nextLine();
                    }
                    generateMap(answer);

                    //see genartion of map
                    /*ListPlace.forEach((list) -> {
                        String ln = "";
                        for (Place plac : list) {
                            ln += (plac.getName() + " ");//+ plac.getNum()+"-->"+plac.getExit()+"|||");
                        }
                        tof.printLineText(ln);
                    });*/
                    

                    drawMap(tof);

                    /**
                     * *-------------------------------------------------------------*
                     */
                    tof.printLineText("Enter player name");
                    String PlayerName = scan.nextLine();
                    while ("".equalsIgnoreCase(PlayerName)) {
                        tof.printLineText("Name unvalide ");
                        PlayerName = scan.nextLine();
                    }
                    tof.printLineText(PlayerName);

                    Place begin = ListPlace.get(0).get(0);

                    HashMap<Integer, Weapons> initTabWeapons = new HashMap<>();
                    initTabWeapons.put(1, new Lazer("Lazer", 2, 1, false, 1, 300));

                    //Player(String name, int hp, int rank, HashMap<Integer, Weapons> tabWeapons, Storage inventory, Shield shield, int _fuelMeter,TextOutputForm _tof)
                    this.myPlayer = new Player(PlayerName, 20, 1, initTabWeapons, new Storage(20), new Shield(true, 5), 10, tof);
                    this.myPlayer.setMyPlace(begin);
                    this.State = GameState.Area; //Get in game

                    break;
                case Selection:

                    tof.printLineText("Type the file or number to load ");
                    tof.printLineText("Type DEL before file to delete it ");
                    tof.printLineText("(Or type NEW to make a new file)");
                    ArrayList<String> saveList = new ArrayList<>();

                    this.ListSaveFiles.forEach((save) -> {
                        saveList.add(save.getName().toLowerCase().replace(FILE_TYPE, ""));
                    });
                    tof.printLineActionNum(saveList);

                    answer = scan.nextLine();//if(st == null)throw new NullPointerException();
                    if (answer == null) {
                        throw new NullPointerException();
                    }
                    /*Verification */
                    boolean acceptNumber = false;
                    if (isInt(answer)) {
                        if (Integer.parseInt(answer) < saveList.size()) {
                            acceptNumber = true;
                        }
                    }

                    while (!"NEW".equalsIgnoreCase(answer) && !saveList.contains(answer.toLowerCase())
                            && !acceptNumber) {
                        tof.printLineText("-----File not reconize----");
                        tof.printLineText("Type the file or number to load ");
                        tof.printLineText("Type DEL before file to delete it ");
                        tof.printLineText("(Or type NEW to make a new file)");
                        answer = scan.nextLine();
                        if (isInt(answer)) {
                            if (Integer.parseInt(answer) < saveList.size()) {
                                acceptNumber = true;
                            }
                        }
                    }
                    int FilePos;
                    if (acceptNumber) {
                        FilePos = Integer.parseInt(answer);
                    } else {
                        FilePos = saveList.indexOf(answer);
                    }
                    tof.printLineText("Your selection : " + answer + " --> " + this.ListSaveFiles.get(FilePos).getName());

                    if ("NEW".equalsIgnoreCase(answer)) {
                        this.State = GameState.New; //Generate new map player ...
                    } else {
                        tof.printLineText("Do you want to load or delete file");
                        tof.printLineText("(Type LOAD or DEL)");
                        answer = scan.nextLine();//if(st == null)throw new NullPointerException();
                        while (!"DEL".equalsIgnoreCase(answer) && !"LOAD".equalsIgnoreCase(answer)) {
                            answer = scan.nextLine();
                            tof.printLineText("-----Command not reconized----");
                            tof.printLineText("Do you want to load or delete file");
                            tof.printLineText("(Type LOAD or DEL)");
                        }

                        if ("DEL".equalsIgnoreCase(answer)) {
                            boolean ok = deleteSave(this.ListSaveFiles.get(FilePos));
                            if (!ok) {
                                tof.printLineText("Error while deleting file");
                            } else {
                                tof.printLineText("File delete");
                            }
                            tof.printLineText("Loading list of save :");
                            listAllSave();
                            if (this.ListSaveFiles.isEmpty()) {
                                tof.printLineText("No save find");
                                tof.printLineText("Generating a new game...");
                                this.State = GameState.New;
                            }

                        } else {
                            boolean ok = loadSave(this.ListSaveFiles.get(FilePos));
                            if (ok) {
                                this.State = GameState.Area;
                            } else {
                                this.State = GameState.New;
                            }
                        }
                    }

                    break;
                case Win:
                    tof.printLineText("You... You did it...\nYou beat the final boss\nGood job !!!\n");
                    tof.printLineText("Let see your score :");

                    tof.printLineText("Money :" + myPlayer.getCredit());
                    tof.printLineText("Damage :" + myPlayer.getAllDamage());
                    tof.printLineText("RepairKit use :" + myPlayer.getNumberRepairKit());
                    tof.printLineText("Place discover :" + myPlayer.getNumberPlaceDiscover());

                    int score = 1000;//
                    score += myPlayer.getCredit() * 99;
                    score -= myPlayer.getAllDamage() * 15;
                    score -= myPlayer.getNumberRepairKit() * 12;
                    score -= myPlayer.getNumberPlaceDiscover() * 123;
                    tof.printLineText("Total score :" + score);
                    if (score < 1000) {
                        tof.printLineText("At least you beat the game");
                    } else {
                        tof.printLineText("Amazing highScore");
                    }
                    if (myPlayer.getNumberRepairKit() == 0) {
                        tof.printLineText("Achievement #How do you first aid#  --> No RepairKit use");
                    }
                    if (myPlayer.getNumberRepairKit() > 10) {
                        tof.printLineText("Achievement #Have you seen my -Winnie the Pooh- bandage#  --> More than 10 RepairKit use");
                    }

                    if (myPlayer.getAllDamage() == 0) {
                        tof.printLineText("Achievement #They are StormTroopers,don't know how to aim#  --> No damage get");
                    }
                    if (myPlayer.getAllDamage() > 100) {
                        tof.printLineText("Achievement #I'm invicible#  --> More than 100 damage get");
                    }

                    if (myPlayer.getNumberPlaceDiscover() < 5) {
                        tof.printLineText("Achievement #That was fast...#  --> Less than 5 place visited");
                    } else if (myPlayer.getNumberPlaceDiscover() < 20) {
                        tof.printLineText("Achievement #Arond the world,Arond the world...#  --> Less than 20 place visited");
                    } else {
                        tof.printLineText("Achievement #Tourist...#  --> More than 20 place visited");
                    }

                    ///save
                    //read 
                    File file = new File("highScore.txt");

                    BufferedReader br = new BufferedReader(new FileReader(file));

                    String st;
                    ArrayList<String> listScore = new ArrayList<>();
                    while ((st = br.readLine()) != null) {
                        listScore.add(st);
                    }

                    //file
                    PrintWriter writer = new PrintWriter("highScore.txt", "UTF-8");
                    writer.println(myPlayer.getNAME() + ":");
                    writer.println(score);

                    writer.println("---");

                    listScore.forEach((str) -> {
                        writer.println(str);
                    });

                    writer.close();

                    tof.printLineText("Do you want to quit or restart the game?");
                    tof.printLineText("(QUIT or RESTART)");
                    answer = scan.nextLine();

                    /*Verification */
                    while (!"QUIT".equalsIgnoreCase(answer) && !"RESTART".equalsIgnoreCase(answer)) {
                        tof.printLineText("Action not reconize");
                        answer = scan.nextLine();
                    }

                    if ("RESTART".equalsIgnoreCase(answer)) {
                        this.State = GameState.Start;
                    } else {
                        this.State = GameState.Quit;
                    }

                    break;

                case GameOver:
                    tof.printLineText("Your Ship is destroy ...");
                    tof.printLineText("GameOver");

                    tof.printLineText("Do you want to quit or restart the game?");
                    tof.printLineText("(QUIT or RESTART)");
                    answer = scan.nextLine();

                    /*Verification */
                    while (!"QUIT".equalsIgnoreCase(answer) && !"RESTART".equalsIgnoreCase(answer)) {
                        tof.printLineText("Action not reconize");
                        answer = scan.nextLine();
                    }

                    if ("RESTART".equalsIgnoreCase(answer)) {
                        this.State = GameState.Start;
                    } else {
                        this.State = GameState.Quit;
                    }

                    break;
                case Area:

                    //show area
                    Thread.sleep(1000);
                    Place localP = myPlayer.getMyPlace();
                    tof.printLineText(localP.getNameLocation());
                    String[] cutName = localP.getNameLocation().split(" ");
                    tof.printFormText(tof.getForm(cutName[0]));
                    tof.printFormText(localP.getDescription());

                    tof.printLineMid();
                    HashMap<String, Enemy> ListOfEnemy = new HashMap<>();
                    if (myPlayer.getMyPlace().enemyNearby()) //enemi in the room
                    {
                        tof.printLineText("Enemy are nearby");
                        //-----------ListOfSO = myPlayer.getListSO();

                        //this.State = GameState.Battle;
                    }
                    if (myPlayer.getMyPlace().getNameLocation().startsWith("Home")) //is in shop
                    {
                        tof.printLineText("Here a shop on the planet");
                        listAction.add("BUY");
                        listAction.add("SELL");
                        //this.State = GameState.Shop;
                    } else {
                        if (listAction.contains("BUY")) {
                            listAction.remove("BUY");
                        }
                        if (listAction.contains("SELL")) {
                            listAction.remove("SELL");
                        }
                    }
                    tof.printLineAction(listAction);

                    tof.printLineText("Select A command");
                    answer = scan.nextLine();

                    /*Verification */
                    String[] tabOfAction = answer.split(" ");

                    while (!listAction.contains(tabOfAction[0].toUpperCase())) {
                        tof.printLineText("Action not reconize");
                        answer = scan.nextLine();//
                        tabOfAction = answer.split(" ");//re split
                    }

                    if ("LOOK MAP".equalsIgnoreCase(answer)) {
                        drawMap(tof);
                    }

                    if ("BUY".equalsIgnoreCase(answer)) {

                    }

                    if ("SELL".equalsIgnoreCase(answer)) {

                    }
                    Action myAction = null;

                    myPlayer.doAction(tabOfAction[0].toUpperCase());
                    //get ending message

                    if (!ListOfEnemy.isEmpty()) //enemi in the room
                    {
                        int luckForAttack = this.myPlayer.getMyPlace().getID_Place() / this.ListPlace.get(this.ListPlace.size()).get(0).getID_Place();//(10 eme planet/80 max)1/8 more we move more they attack you
                        for (Map.Entry<String, Enemy> thisEmap : ListOfEnemy.entrySet()) {
                            String _key = thisEmap.getKey();
                            Enemy _e = thisEmap.getValue();

                            if (randomInt(this.ListPlace.get(this.ListPlace.size()).get(0).getID_Place()) < luckForAttack)// 0-80 < 1/8 --> 12.5%
                            {
                                tof.printLineText(_key + "attack you ...");
                                _e.useWeapon(null, myPlayer);///quand attaquer affiche
                            }
                            if (myPlayer.is_destroy()) {
                                this.State = GameState.GameOver;
                                break;
                            }
                        }
                    }

                    if (myPlayer.is_destroy()) {
                        this.State = GameState.GameOver;
                        break;
                    }
                    int num1 = this.ListPlace.get(this.ListPlace.size() - 1).get(0).getID_Place();
                    int num2 = this.myPlayer.getMyPlace().getID_Place();
                    if (!myPlayer.getMyPlace().enemyNearby() && (num1 == num2)) //no enemi and last room
                    {
                        this.State = GameState.Win;
                    }

                    break;

                case Quit:
                    tof.printLineText("Do you want to save ?");

                    tof.printLineText("(Yes or No)");
                    answer = scan.nextLine();

                    /*Verification */
                    while (!"YES".equalsIgnoreCase(answer) && !"NO".equalsIgnoreCase(answer)) {
                        tof.printLineText("Action not reconize");
                        answer = scan.nextLine();
                    }

                    if ("YES".equalsIgnoreCase(answer)) {
                        tof.printLineText("Name save");
                        String FileName = scan.nextLine();

                        while ("".equalsIgnoreCase(FileName)) {
                            tof.printLineText("unvalide");
                            FileName = scan.nextLine();
                        }
                        tof.printLineText("Saving");
                        String FilePath = FileName + FILE_TYPE;
                        newSave(FilePath);
                        tof.printLineText("Save complete --> " + FilePath);
                    }

                    tof.printFormText("Thanx for playing\nBrouth by\nKillian\nRomain\nThomas\n");
                    tof.printLineText("Any resemblance to real and actual names is purely coincidental.");
                    tof.printLineText("no animals were mistreated during coding...");
                    tof.printLineText("Besides the programmers who leaked blood and tear to finish the project.");
                    tof.printLineText("Press enter to quit ...");
                    scan.nextLine();

                    this.State = GameState.End; //get out of while for finish main()
                    break;
            }

            if (answer.equalsIgnoreCase("QUIT")) {
                this.State = GameState.Quit; //get ending message
            } else if (answer.equalsIgnoreCase("SAVE")) {
                tof.printLineText("Name save");
                String FileName = scan.nextLine();

                while ("".equalsIgnoreCase(FileName)) {
                    tof.printLineText("unvalide");
                    FileName = scan.nextLine();
                }
                tof.printLineText("Saving");
                //DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-mm-yy");  format
                //LocalDateTime now = LocalDateTime.now();  CurrentTime
                //String FilePath = FileName + "_" + dtf.format(now) + FILE_TYPE;Name by Date
                String FilePath = FileName + FILE_TYPE;
                newSave(FilePath);
                tof.printLineText("Save complete --> " + FilePath);
            }//get ending message

        } while (this.State != GameState.End);
    }

    private boolean loadSave(File myFile) throws IOException {
        // TODO - implement Game.Load
        ObjectInputStream ios = null;
        try {
            FileInputStream streamIn = new FileInputStream(myFile);
            ios = new ObjectInputStream(streamIn);
            //this.ListPlace = (ArrayList<ArrayList<Place>>) ios.readObject();
            int p = (int) ios.readObject();
            //this.myPlayer = p;
            System.out.println(p);
            //this.sizeOfMap = (int) ios.readObject();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (ios != null) {
                ios.close();
            }
        }

        return true;
    }

    private void listAllSave() {
        // TODO - implement Game.ListAllSave
        this.ListSaveFiles.clear();
        File dir = new File(".");//. for current
        File[] directoryListing = dir.listFiles();
        if (directoryListing != null) {
            for (File child : directoryListing) {
                // Do something with child
                if (child.getName().contains(FILE_TYPE)) {
                    this.ListSaveFiles.add(child);
                }
            }
        }
    }

    /**
     *
     * @param saveFile
     * @return
     */
    private boolean deleteSave(File saveFile) {
        // TODO - implement Game.DeleteSave
        return saveFile.delete();
    }

    /**
     *
     * @param FileName
     * @throws java.io.IOException
     */
    private void newSave(String FilePath) throws IOException {
        // TODO - implement Game.NewGame

        ObjectOutputStream oos = null;
        FileOutputStream fout = null;

        String fileRep = FilePath;
        try {
            File myFile = new File(fileRep);
            fout = new FileOutputStream(myFile);
            //System.out.println(myFile.getPath());
            oos = new ObjectOutputStream(fout);
            //oos.writeObject(this.ListPlace);
            // oos.writeObject(this.myPlayer);
            oos.writeObject(this.sizeOfMap);
            oos.close();
            fout.close();
        } catch (IOException ex) {
        } finally {
            if (oos != null) {
                oos.close();
            }
        }

    }

    private void generateMap(String sizeOption) {
        // TODO - implement Game.NewGame
        //throw new UnsupportedOperationException();

        //set some random name
        int nbOfName = 5;

        //String[] Sname = {"Alpha", "Beta", "Teta", "Omega", "Zeta"};
        //String[] Lname = {"Naillik", "Quamicaz", "Niamor", "LaPalma", "Nimesis"};
        String[] Sname = {"A", "B", "T", "O", "Z"};
        String[] Lname = {"N", "Q", "N", "L", "N"};
        String[] Sdescription = {
            "This FNAME is a typical place for tourists.\n"
            + "It's not hard to find what you're looking for.\n",
            "This FNAME is the same everywhere, so easy to lose ...\n",
            "It feels good here on a FNAME, but it is not necessarily the place for a family.\n",
            "With this FNAME we have access to Yensid channel, a good return to childhood ...\n",
            "This FNAME is beautiful, but does not have the taste of cheese.\n"};
        String[] Ldescription = {
            "Its danger level is 0.\n"
            + "Pacific and friendly.\n",
            "Its danger level is 2.\n"
            + "Pacific but watch out for the thief\n",
            "Its danger level is 4.\n"
            + "Nice place but some fight in the bars ....\n",
            "Its danger level is 6.\n"
            + "Pirate, killer, comet, robot, clown ...\n "
            + "A lot of non-recommendable person for babysitting ...\n",
            "Its danger level is 8.\n"
            + "On a scale of richter, it seems dangerous for a scout camp.\n",};
        String[] nameMaterials = {"Diamond", "Rubis", "Saphir", "Amenysth", "Crystal"};
        int[] priceMaterials = {100, 80, 65, 49, 20};

        //set a size
        int size_step = 1;//longeur
        if ("MEDIUM".equalsIgnoreCase(sizeOption)) {
            size_step *= 2;
        } else if ("BIG".equalsIgnoreCase(sizeOption)) {
            size_step *= 3;
        }
        //int generationSize = size_step;

        int numPlanet = 0;
        ArrayList<Place> listStepPlace = new ArrayList<>();

        //
        Place homeP = new Place("Home Planet", "Home sweet home\n" + Sdescription[0].replace("FNAME", "home") + Ldescription[0], numPlanet);
        listStepPlace.add(homeP);
        ListPlace.add((ArrayList<Place>) listStepPlace.clone());//clone car généré dans une liste temporaire

        listStepPlace.clear();
        int fnRnd = 1; //nb planet from step before
        for (int step = 1; step <= size_step * 2; step++) {
            for (int step_hight = 1; step_hight <= size_step; step_hight++) {
                if (step < size_step) {
                    fnRnd = randomInt_range(fnRnd - 1, fnRnd * 2) + 2;//more planet
                } else {
                    fnRnd = (int) Math.ceil(fnRnd * 8 / 10);//less after middle
                }                //if(fnRnd > (size_step*2)+1) fnRnd = (size_step*2)+1; //depasse pas la limite 2*2 = 4 planet par step

                for (int rnd = 0; rnd <= fnRnd; rnd++) {
                    numPlanet++;
                    int rFn = randomInt(nbOfName);
                    int rSn = randomInt(nbOfName);
                    Place p = new Place(FNAME[rFn] + "" + Sname[rSn] + "" + Lname[randomInt(nbOfName)],
                            Sdescription[rFn].replace("FNAME", FNAME[rFn]) + Ldescription[rSn], numPlanet);

                    HashMap<String, Items> listItemsToAdd = new HashMap<>();
                    if (randomInt(100) < 25)//si 0 ----> 25% RepairKit
                    {
                        listItemsToAdd.put("RepairKit", new RepairKit(1));
                    }
                    if (randomInt(100) < 25)//si 0 ----> 1/2 Barrel
                    {
                        listItemsToAdd.put("Barrel of fuel", new BarrelOfFuel(1));
                    }
                    if (randomInt(100) < 25)//si 0 ----> 1/2 ammo pack 2 --> 4
                    {
                        listItemsToAdd.put("Ammo", new Ammo(2));
                    }
                    if (randomInt(100) < 60)//si 0 ----> 20 -100 max
                    {
                        listItemsToAdd.put("Credit", new Credit(randomInt(80) + 20));
                    }

                    if (randomInt(100) < 30)//si 0 ----> material
                    {
                        int rnd_mat = randomInt(4);
                        listItemsToAdd.put("Material", new Material(nameMaterials[rnd_mat], priceMaterials[rnd_mat], randomInt(10)));
                    }

                    listStepPlace.add(p);
                }
                ListPlace.add((ArrayList<Place>) listStepPlace.clone());
                listStepPlace.clear();
            }
        }
        numPlanet++;

        listStepPlace.clear();
        Place bossP = new Place("Final Boss", "This is it...\nThe final boss...\n" + Sdescription[4].replace("FNAME", "place") + Ldescription[4], numPlanet);
        listStepPlace.add(bossP);

        ListPlace.add((ArrayList<Place>) listStepPlace.clone());//clone car généré dans une liste temporaire

        //Reverse
        //Collections.reverse(ListPlace);
        ListPlace.get(1).forEach((p) -> {
            ListPlace.get(0).get(0).addExit(new Exit(randomInt(2) + 1, p));
        });
        this.sizeOfMap = getMaxPlanetOfList();//get max for draw
        //generate exit
        
        //rnd 1-3
        Place[][] tabListLignePlace =new Place[sizeOfMap][ListPlace.size()];

        for (int listnum = 0; listnum < ListPlace.size()-1; listnum++) {

            ArrayList<Place> list = ListPlace.get(listnum);

            for (int numero= 0; numero < list.size(); numero++)
            {
                //Place pl = new Place("","",-1);
                //tabListLignePlace[numero].add(pl);
                tabListLignePlace[numero][listnum] = list.get(numero);
            }

            for (int lastnumero = list.size(); lastnumero < sizeOfMap; lastnumero++) {
               tabListLignePlace[lastnumero][listnum] = null;//
            }

        }
        
        for (int posCase = sizeOfMap - 1; posCase > 0; posCase--)//jusqua 1
        {
            for(int slist = 0;slist<tabListLignePlace[posCase].length-3;slist++)
            {
                if(tabListLignePlace[posCase][slist]!=null)
                {
                    Place a = tabListLignePlace[posCase][slist];
                    for(int i = -2;i<=2;i+=2)
                    {
                        if((sizeOfMap - 1) >= posCase+i && posCase+i >= 0)
                        {
                            
                            if(tabListLignePlace[posCase+i][slist+1]!=null){
                                Place b = tabListLignePlace[posCase+i][slist+1];
                                a.addExit(new Exit(randomInt(2)+1,b));
                            }
                        }
                        else if((sizeOfMap - 1) >= posCase+i && posCase+i >=-2)
                        {
                            
                            if(tabListLignePlace[0][slist+1]!=null)
                            {
                                Place b = tabListLignePlace[0][slist+1];
                                a.addExit(new Exit(randomInt(2)+1,b));
                            }
                        }
                    }
                }
            }
        }
                  
    }
        //Simple fonction for an int to random 5 --> 0-4 (pour simplifier l'écriture dans le code)
    private int randomInt(int nb) {
        return (int) (Math.random() * nb);
    }

    private int randomInt_range(int min, int max) {
        int rnd = 0;
        if (min < 0) {
            rnd = min + (int) (Math.random() * max - min);
        } else {
            rnd = randomInt(max);
        }
        return rnd;
    }

    private Action getAction(String strAction) {
        for (Action var : Action.values()) {
            if (strAction.equalsIgnoreCase(var.name())) {
                return var;
            }
        }
        return null;
    }
//get a form from the name planet --> O

    private String getFormOfPlace(String name) {
        int pos = 0;

        if (myPlayer != null && myPlayer.getMyPlace().getNameLocation().equals(name))//posisiton player
        {
            return "  P  ";
        }
        for (String firstName : FNAME) {//match we final name
            if (name.startsWith(firstName)) {
                return this.FNAMEFORM[pos];
            }
            pos++;
        }
        if (name.startsWith("Final"))//Final place
        {
            return "  B  ";
        }
        if (name.startsWith("Home"))//first place
        {
            return "  S  ";
        }
        return "  N  ";

    }

    //when load or new map we retore the size to make it printable
    private int getMaxPlanetOfList() {
        int max = 0;
        for (ArrayList list : ListPlace) {
            if (max < list.size()) {
                max = list.size();  //biggest size of a list of planet
            }
        }
        return max;
    }

    //Prepare the pseudo form of the map to make it printable in string
    private String getDrawMap() {
        String[] tabMapOfString = new String[sizeOfMap];//tableau listant par ligne

        for (int num = 0; num < ListPlace.size(); num++) {

            ArrayList<Place> list = ListPlace.get(num);

            for (int numPlanet = 0; numPlanet < list.size(); numPlanet++) {
                if (tabMapOfString[numPlanet] == null) {
                    tabMapOfString[numPlanet] = "";//init of case
                }
                tabMapOfString[numPlanet] += (getFormOfPlace(list.get(numPlanet).getNameLocation()));
                if (num > 9) {
                    tabMapOfString[numPlanet] += " ";
                }
            }

            for (int lastCase = list.size(); lastCase < sizeOfMap; lastCase++) {
                if (tabMapOfString[lastCase] == null) {
                    tabMapOfString[lastCase] = "";//init of case
                }
                tabMapOfString[lastCase] += "     ";
                if (num > 9) {
                    tabMapOfString[lastCase] += " ";
                }
            }

        }

        String mapString = "";
        for (int posCase = sizeOfMap - 1; posCase > 0; posCase--)//jusqua 1
        {
            if ((posCase % 2) != 0)//impair
            {
                mapString += tabMapOfString[posCase] + "\n";
            }
        }

        for (int posCase = 0; posCase < sizeOfMap; posCase++)//jusquau max -1
        {
            if (posCase % 2 == 0 || posCase == 0)//pair
            {
                mapString += tabMapOfString[posCase] + "\n";
            }
        }
        return mapString;

    }

    //Draw the map
    private void drawMap(TextOutputForm tof) {
        String lineNumber = "";
        for (int i = 0; i < ListPlace.size(); i++) {
            lineNumber += "  " + i + "  ";
        }
        tof.printLineMid();
        tof.printLineText("S-->Start Place/B-->Boss/P-->Player");
        tof.printLineText("S-->Start Place/B-->Boss/P-->Player");
        int pos = 0;
        String lineText = "";
        for (String firstName : FNAME) {
            lineText += FNAMEFORM[pos].replace(" ", "") + "-->" + firstName + "/";//form " O ".replace --> "O"
            pos++;
        }
        tof.printLineText(lineText);
        tof.printLineMid();
        tof.printFormText(lineNumber + "\n\n" + getDrawMap());
        tof.printLineMid();
    }

    //Check for an input string is form of int
    private boolean isInt(String val) {
        try {
            // checking valid integer using parseInt() method 
            Integer.parseInt(val);
            //System.out.println(val + " is a valid integer number"); 
            return true;
        } catch (NumberFormatException e) {
            //System.out.println(val + " is not a valid integer number"); 
            return false;
        }
    }

}
