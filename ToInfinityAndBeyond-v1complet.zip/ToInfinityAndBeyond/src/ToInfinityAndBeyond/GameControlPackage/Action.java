package ToInfinityAndBeyond.GameControlPackage;

public enum Action {
	USE,
	GO,
	LOOK,
	TAKE,
	HELP,
	ATTACK,
	QUIT,
	DROP,
	WEAPON,
        UPGRADE
}