package Game.SpacialPackage;

import Game.ZoneIteractionsPackage.*;
import Game.GameControlPackage.*;

public class Player extends SpacialObject {

	public void upRank() {
		// TODO - implement Player.upRank
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param this_item
	 */
	public void UseThisItems(Items this_item) {
		// TODO - implement Player.UseThisItems
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisItem
	 */
	public boolean haveThisItem(Items thisItem) {
		// TODO - implement Player.haveThisItem
		throw new UnsupportedOperationException();
	}

	public String getInventory() {
		// TODO - implement Player.getInventory
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisAction
	 */
	public void doAction(Action thisAction) {
		// TODO - implement Player.doAction
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisWeapon
	 * @param position
	 */
	public void equipWeapon(Weapons thisWeapon, int position) {
		// TODO - implement Player.equipWeapon
		throw new UnsupportedOperationException();
	}

	public void unequipWeapons() {
		// TODO - implement Player.unequipWeapons
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param value
	 */
	public void addLife(int value) {
		// TODO - implement Player.addLife
		throw new UnsupportedOperationException();
	}

	public Weapons selectWeapon() {
		// TODO - implement Player.selectWeapon
		throw new UnsupportedOperationException();
	}

}