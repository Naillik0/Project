package Game.SpacialPackage;

import Game.ZoneIteractionsPackage.*;

public class SpacialObject {

	private Shield myShield;
	private Weapons tabEquipedWeapons;
	private Storage myStorage;
	private Place myPlace;
	private String Name;
	private int LifePoint;
	private final int LIFEPOINTMAX;
	private int Rank;

	/**
	 * 
	 * @param _name
	 * @param LP
	 * @param Rank
	 */
	public SpacialObject(String _name, int LP, int Rank) {
		// TODO - implement SpacialObject.SpacialObject
		throw new UnsupportedOperationException();
	}

	public boolean is_destroy() {
		// TODO - implement SpacialObject.is_destroy
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param damage
	 */
	public void getHit(int damage) {
		// TODO - implement SpacialObject.getHit
		throw new UnsupportedOperationException();
	}

	public Items<HashMap> getListItems() {
		// TODO - implement SpacialObject.getListItems
		throw new UnsupportedOperationException();
	}

}