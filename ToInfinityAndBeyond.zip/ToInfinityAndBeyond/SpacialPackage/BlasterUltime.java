package Game.SpacialPackage;

public class BlasterUltime extends Weapons {

	public BlasterUltime() {
		// TODO - implement BlasterUltime.BlasterUltime
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param other
	 */
	public void useW(Player other) {
		// TODO - implement BlasterUltime.useW
		throw new UnsupportedOperationException();
	}

}