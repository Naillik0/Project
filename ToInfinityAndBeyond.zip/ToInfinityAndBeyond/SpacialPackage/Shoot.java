package Game.SpacialPackage;

public interface Shoot {

	/**
	 * 
	 * @param Weapon
	 * @param enemi
	 */
	abstract void UseWeapon(Weapons Weapon, Enemy enemi);

}