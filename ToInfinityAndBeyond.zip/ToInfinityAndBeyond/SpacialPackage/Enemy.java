package Game.SpacialPackage;

public class Enemy extends SpacialObject {

	public void loseItems() {
		// TODO - implement Enemy.loseItems
		throw new UnsupportedOperationException();
	}

}