package Game.SpacialPackage;

public class Blaster extends Weapons {

	public Blaster() {
		// TODO - implement Blaster.Blaster
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param other
	 */
	public void useW(Player other) {
		// TODO - implement Blaster.useW
		throw new UnsupportedOperationException();
	}

}