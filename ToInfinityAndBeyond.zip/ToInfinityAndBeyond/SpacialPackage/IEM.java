package Game.SpacialPackage;

public class IEM extends Weapons {

	public IEM() {
		// TODO - implement IEM.IEM
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param other
	 */
	public void useW(Player other) {
		// TODO - implement IEM.useW
		throw new UnsupportedOperationException();
	}

}