package Game.SpacialPackage;

public class Bomb extends Weapons {

	public Bomb() {
		// TODO - implement Bomb.Bomb
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param other
	 */
	public void useW(Player other) {
		// TODO - implement Bomb.useW
		throw new UnsupportedOperationException();
	}

}