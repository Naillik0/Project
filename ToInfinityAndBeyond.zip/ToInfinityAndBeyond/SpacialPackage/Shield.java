package Game.SpacialPackage;

public class Shield {

	private boolean Actif;
	private boolean Energy;
	private final int ENERGYMAX;

	public Shield() {
		// TODO - implement Shield.Shield
		throw new UnsupportedOperationException();
	}

	public void ActivateShield() {
		// TODO - implement Shield.ActivateShield
		throw new UnsupportedOperationException();
	}

	public void DesactivateShield() {
		// TODO - implement Shield.DesactivateShield
		throw new UnsupportedOperationException();
	}

	public int getEnergy() {
		// TODO - implement Shield.getEnergy
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param value
	 */
	public void DecreaseEnergy(int value) {
		// TODO - implement Shield.DecreaseEnergy
		throw new UnsupportedOperationException();
	}

	public void ResetEnergy() {
		// TODO - implement Shield.ResetEnergy
		throw new UnsupportedOperationException();
	}

}