package Game.ZoneIteractionsPackage;

import Game.SpacialPackage.*;

public class Material extends Items {

	public Material() {
		// TODO - implement Material.Material
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisPlayer
	 */
	public void useItemOn(Player thisPlayer) {
		// TODO - implement Material.useItemOn
		throw new UnsupportedOperationException();
	}

}