package Game.ZoneIteractionsPackage;

import Game.SpacialPackage.*;

public abstract class Items {

	private final String NAME;
	private int Quantity;
	private final int PRICE;

	/**
	 * 
	 * @param thisPlayer
	 */
	public abstract void useItemOn(Player thisPlayer);

	/**
	 * 
	 * @param name
	 * @param _quantity
	 * @param price
	 */
	public Items(String name, int _quantity, int price) {
		// TODO - implement Items.Items
		throw new UnsupportedOperationException();
	}

}