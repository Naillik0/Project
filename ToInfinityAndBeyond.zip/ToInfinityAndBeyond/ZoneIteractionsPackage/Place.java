package Game.ZoneIteractionsPackage;

import java.util.*;
import Game.SpacialPackage.*;

public class Place {

	private final String NAME_LOCATION;
	private final String DESCRIPTION;
	private Collection<Exit> MapOfExit;
	private Items ListOfItems;
	private SpacialObject ListOfSO;

	public String getNameLocation() {
		// TODO - implement Place.getNameLocation
		throw new UnsupportedOperationException();
	}

	public String getDescription() {
		// TODO - implement Place.getDescription
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param _item
	 */
	public void addItem(Items _item) {
		// TODO - implement Place.addItem
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nameItem
	 */
	public void removeItem(String nameItem) {
		// TODO - implement Place.removeItem
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Enemy
	 */
	public void addEnemy(Player Enemy) {
		// TODO - implement Place.addEnemy
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Enemy
	 */
	public void removeEnemy(Player Enemy) {
		// TODO - implement Place.removeEnemy
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param _exit
	 */
	public void addExit(int _exit) {
		// TODO - implement Place.addExit
		throw new UnsupportedOperationException();
	}

	public void displayExit() {
		// TODO - implement Place.displayExit
		throw new UnsupportedOperationException();
	}

	public Place goExit() {
		// TODO - implement Place.goExit
		throw new UnsupportedOperationException();
	}

}