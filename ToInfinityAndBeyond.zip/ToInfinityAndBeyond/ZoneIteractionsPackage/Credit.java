package Game.ZoneIteractionsPackage;

import Game.SpacialPackage.*;

public class Credit extends Items {

	public Credit() {
		// TODO - implement Credit.Credit
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisPlayer
	 */
	public void useItemOn(Player thisPlayer) {
		// TODO - implement Credit.useItemOn
		throw new UnsupportedOperationException();
	}

}