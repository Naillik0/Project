package Game.ZoneIteractionsPackage;

import Game.SpacialPackage.*;

public class Ammo extends Items {

	public Ammo() {
		// TODO - implement Ammo.Ammo
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisPlayer
	 */
	public void useItemOn(Player thisPlayer) {
		// TODO - implement Ammo.useItemOn
		throw new UnsupportedOperationException();
	}

}