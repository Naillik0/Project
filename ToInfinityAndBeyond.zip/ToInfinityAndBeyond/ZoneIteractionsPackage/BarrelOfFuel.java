package Game.ZoneIteractionsPackage;

import Game.SpacialPackage.*;

public class BarrelOfFuel extends Items {

	/**
	 * 
	 * @param thisPlayer
	 */
	public void useItemOn(Player thisPlayer) {
		// TODO - implement BarrelOfFuel.useItemOn
		throw new UnsupportedOperationException();
	}

	public BarrelOfFuel() {
		// TODO - implement BarrelOfFuel.BarrelOfFuel
		throw new UnsupportedOperationException();
	}

}