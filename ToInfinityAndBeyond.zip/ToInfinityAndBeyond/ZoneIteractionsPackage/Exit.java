package Game.ZoneIteractionsPackage;

public class Exit {

	private final int DISTANCE;
	private Place[] NextPlace;
	private boolean Close;

	public Place getNextPlace() {
		// TODO - implement Exit.getNextPlace
		throw new UnsupportedOperationException();
	}

	public void getDistance() {
		// TODO - implement Exit.getDistance
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Distance
	 * @param NextPlace
	 * @param _isOpen
	 */
	public Exit(int Distance, Place NextPlace, boolean _isOpen) {
		// TODO - implement Exit.Exit
		throw new UnsupportedOperationException();
	}

	public boolean isClose() {
		// TODO - implement Exit.isClose
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Close
	 */
	public void setClose(boolean Close) {
		// TODO - implement Exit.setClose
		throw new UnsupportedOperationException();
	}

	public void getNameNextPlace() {
		// TODO - implement Exit.getNameNextPlace
		throw new UnsupportedOperationException();
	}

}