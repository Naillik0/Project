package Game.ZoneIteractionsPackage;

import Game.SpacialPackage.*;

public class RepairKit extends Items {

	public RepairKit() {
		// TODO - implement RepairKit.RepairKit
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisPlayer
	 */
	public void useItemOn(Player thisPlayer) {
		// TODO - implement RepairKit.useItemOn
		throw new UnsupportedOperationException();
	}

}