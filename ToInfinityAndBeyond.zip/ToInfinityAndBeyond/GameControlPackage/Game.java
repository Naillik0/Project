package Game.GameControlPackage;

import Game.ZoneIteractionsPackage.*;
import java.util.*;
import Game.SpacialPackage.*;

public class Game {

	private GameState State = GameState.Start;
	private File ListSaveFiles;
	private Place ListPlace;
	Collection<Place> ListOfPlace;
	private Player myPlayer;
	private Action Actions;
	private GameState myState;

	public Game() {
		// TODO - implement Game.Game
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param SaveFile
	 */
	public void Load(File SaveFile) {
		// TODO - implement Game.Load
		throw new UnsupportedOperationException();
	}

	public List ListAllSave() {
		// TODO - implement Game.ListAllSave
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param SaveFile
	 */
	public void DeleteSave(File SaveFile) {
		// TODO - implement Game.DeleteSave
		throw new UnsupportedOperationException();
	}

	public void Save() {
		// TODO - implement Game.Save
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param FileName
	 */
	public void NewGame(String FileName) {
		// TODO - implement Game.NewGame
		throw new UnsupportedOperationException();
	}

	public void GetAction() {
		// TODO - implement Game.GetAction
		throw new UnsupportedOperationException();
	}

	public void SetAction() {
		// TODO - implement Game.SetAction
		throw new UnsupportedOperationException();
	}

	public void RefreshText() {
		// TODO - implement Game.RefreshText
		throw new UnsupportedOperationException();
	}

}