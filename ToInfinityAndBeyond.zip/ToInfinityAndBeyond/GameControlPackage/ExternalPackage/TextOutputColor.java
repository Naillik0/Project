package Game.GameControlPackage.ExternalPackage;

import Game.GameControlPackage.*;

public class TextOutputColor extends Game {

	private String RED;
	private String BLUE;
	private String Etc;

}