package Game.GameControlPackage;

public enum GameState {
	Start,
	Selection,
	Option,
	Battle,
	Area,
	Shop
}