package Game.GameControlPackage;

public interface TextOutputForm {

	int SIZEOFSCREEN = 130;

	void TextOutputForm();

	void PrintText();

	void PrintTitle();

	void PrintCharPicture();

	void PrintUDLigne();

	void PrintMidLigne();

	void PrintActions();

}