package Game.GameControlPackage;

public enum Action {
	USE,
	GO,
	LOOK,
	TAKE,
	HELP,
	ATTACK,
	QUIT,
	DROP
}