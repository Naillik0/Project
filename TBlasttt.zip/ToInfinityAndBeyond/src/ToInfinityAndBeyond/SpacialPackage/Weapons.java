package ToInfinityAndBeyond.SpacialPackage;

import ToInfinityAndBeyond.ZoneIneractionsPackage.Items;


public abstract class Weapons extends Items{
	private int damage;
	private int Rank;
	private boolean useAmmo;
        private static final boolean isUsable = false;
	
	public Weapons(String name, int damageDefault, int rank, boolean useAmm, int quant, int price) {
		super(name, quant, price,isUsable);
                this.damage=damageDefault;
                this.Rank=rank;
                this.useAmmo=useAmm;
	}
        
	public void upRank() {
		this.Rank++;
                this.damage=damage*2;
	}

        public int getDamage(){
            return this.damage;
        }
	public abstract boolean haveAmmo(SpacialObject theShooter);

   public boolean needAmmo() {
       return useAmmo;
    }

}