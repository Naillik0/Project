package ToInfinityAndBeyond.SpacialPackage;

import ToInfinityAndBeyond.ZoneIneractionsPackage.Items;
import java.util.HashMap;

public class Bomb extends Weapons {

    
    public Bomb() {
	super("Bomb", 5, 1, true, 1, 200);
    }

    @Override
    public boolean haveAmmo(SpacialObject theShooter) {
        HashMap<String,Items> lesItems= theShooter.getMyStorage().getListItems();
        return lesItems.containsKey("Ammo");
    }

    @Override
    public void useItemOn(SpacialObject target) {
        target.getHit(this.getDamage(),-1,1);

        
    }

    private boolean haveAmmo() {
        return super.needAmmo();
    }



}