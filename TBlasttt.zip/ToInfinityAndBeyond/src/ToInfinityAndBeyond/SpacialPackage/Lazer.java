package ToInfinityAndBeyond.SpacialPackage;

public class Lazer extends Weapons {

	
    public Lazer() {
        super("Lazer", 3, 1, false, 1, 172);
    }

    @Override
    public boolean haveAmmo(SpacialObject theShooter) {
        return true;
    }

    @Override
    public void useItemOn(SpacialObject target) {
        target.getHit(this.getDamage(),1,2);
    }

}