package ToInfinityAndBeyond.SpacialPackage;

public class BlasterUltime extends Weapons {

    public BlasterUltime() {
        super("Blaster Ultime", 20, 5, false, 1, 1000);
    }

    @Override
    public boolean haveAmmo(SpacialObject theShooter) {
        return true;
    }

    @Override
    public void useItemOn(SpacialObject target) {
        target.getHit(this.getDamage(),2,2); // X2 sur la vie et bouclier
    }

}