package ToInfinityAndBeyond.SpacialPackage;

public class IEM extends Weapons {

    public IEM() {
        super("IEM", 5, 1, false, 1, 100);
    }

    @Override
    public boolean haveAmmo(SpacialObject theShooter){
        return true;
    }

    @Override
    public void useItemOn(SpacialObject target) {
        target.getHit(this.getDamage(),2,1);
    }

}