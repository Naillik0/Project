/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ToInfinityAndBeyond;

import ToInfinityAndBeyond.GameControlPackage.Action;
import ToInfinityAndBeyond.GameControlPackage.Game;
import ToInfinityAndBeyond.GameControlPackage.TextOutputForm;
import ToInfinityAndBeyond.SpacialPackage.Player;
import ToInfinityAndBeyond.SpacialPackage.Shield;
import ToInfinityAndBeyond.SpacialPackage.Storage;
import ToInfinityAndBeyond.SpacialPackage.Weapons;
import ToInfinityAndBeyond.ZoneIneractionsPackage.Ammo;
import ToInfinityAndBeyond.ZoneIneractionsPackage.Credit;
import ToInfinityAndBeyond.ZoneIneractionsPackage.Exit;
import ToInfinityAndBeyond.ZoneIneractionsPackage.Items;
import ToInfinityAndBeyond.ZoneIneractionsPackage.Material;
import ToInfinityAndBeyond.ZoneIneractionsPackage.Place;
import ToInfinityAndBeyond.ZoneIneractionsPackage.RepairKit;
import java.io.IOException;
import java.util.HashMap;

/**
 *
 * @author Romain
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException, IOException, CloneNotSupportedException, ClassNotFoundException {
       
        
        Game myGame = new Game();
        
        
        
        /*
        HashMap<Integer, Weapons> tabWeapon = new HashMap<>();
        Storage inventory = new Storage(10);
        Shield shield = new Shield(true, 5);
        TextOutputForm tof = new TextOutputForm();
        
        
        Player p =new Player("Pedro", 20, 1,tabWeapon, inventory, shield, 10, tof);
        Place pS=new Place("Start Planete", "Bonjour vous ete sur la planete Start",1);
        Place pA=new Place("A", "Bonjour vous ete sur la planete A",2);
        Place pB=new Place("B", "Bonjour vous ete sur la planete B",3);
        Place pC=new Place("C", "Bonjour vous ete sur la planete C",4);
        
        
        Exit exVA=new Exit(1, pA);
        Exit exVB=new Exit(15, pB);
        Exit exVC=new Exit(5, pC);
        
        pS.addExit(exVA);
        pS.addExit(exVB);
        pA.addExit(exVB);
        pA.addExit(exVC);
        pB.addExit(exVA);
        pB.addExit(exVC);
        pC.addExit(exVA);
        pC.addExit(exVB);
        
        p.setMyPlace(pS);
        
        Items RepareK = new RepairKit(10);
        Items money = new Credit(1);
        Items Material = new Material("Diamond", 1, 100);
        Items Ammo = new Ammo(2);
        
        pA.addItem(RepareK);
        pA.addItem(money);
        
        pA.addItem(Ammo);
        pA.addItem(Material);
        
        pC.addItem(Ammo);
        pC.addItem(Material);
        
        p.doAction(Action.GO);
        p.doAction(Action.LOOK);
        p.doAction(Action.TAKE);

        p.doAction(Action.DROP);
        p.doAction(Action.LOOK);
        p.doAction(Action.DROP);
        p.doAction(Action.DROP);
        p.doAction(Action.DROP);
        
        /*
        p.showExit();
        p.getPlanete().Searsh();
        p.take("Credit");
        p.getPlanete().Searsh();
        p.go(pB);
        p.Inventory();
                */
    }
    
}
