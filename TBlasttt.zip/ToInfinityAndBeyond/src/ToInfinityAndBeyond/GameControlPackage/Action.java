package ToInfinityAndBeyond.GameControlPackage;

public enum Action {
	USE,
	GO,
	LOOK,
        MAP,
	TAKE,
	HELP,
        DROP,
	WEAPON,
        UPGRADE,
	ATTACK,
        SAVE,
	QUIT

}