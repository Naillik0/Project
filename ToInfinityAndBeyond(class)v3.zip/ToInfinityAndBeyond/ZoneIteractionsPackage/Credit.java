package ToInfinityAndBeyond.ZoneIteractionsPackage;

import ToInfinityAndBeyond.SpacialPackage.*;

public class Credit extends Items {

	/**
	 * 
	 * @param _quantity
	 */
	public Credit(int _quantity) {
		// TODO - implement Credit.Credit
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisPlayer
	 */
	public void useItemOn(Player thisPlayer) {
		// TODO - implement Credit.useItemOn
		throw new UnsupportedOperationException();
	}

}