package ToInfinityAndBeyond.ZoneIteractionsPackage;

import ToInfinityAndBeyond.SpacialPackage.*;

public class Ammo extends Items {

	/**
	 * 
	 * @param _quantity
	 */
	public Ammo(int _quantity) {
		// TODO - implement Ammo.Ammo
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisPlayer
	 */
	public void useItemOn(Player thisPlayer) {
		// TODO - implement Ammo.useItemOn
		throw new UnsupportedOperationException();
	}

}