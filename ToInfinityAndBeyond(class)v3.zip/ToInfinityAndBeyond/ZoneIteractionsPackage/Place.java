package ToInfinityAndBeyond.ZoneIteractionsPackage;

import ToInfinityAndBeyond.SpacialPackage.*;

public class Place {

	private final String NAME_LOCATION;
	private final String DESCRIPTION;
	private Exit MapOfExit;
	private Items ListOfItems;
	private SpacialObject ListOfSO;
	private final int IDPLACE;

	public String getNameLocation() {
		// TODO - implement Place.getNameLocation
		throw new UnsupportedOperationException();
	}

	public String getDescription() {
		// TODO - implement Place.getDescription
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param _item
	 */
	public void addItem(Items _item) {
		// TODO - implement Place.addItem
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nameItem
	 */
	public Items removeItem(String nameItem) {
		// TODO - implement Place.removeItem
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param _so
	 */
	public void addSpacialObject(SpacialObject _so) {

	}

	/**
	 * 
	 * @param _so
	 */
	public void removeSpacialObject(SpacialObject _so) {

	}

	/**
	 * 
	 * @param _exit
	 */
	public void addExit(int _exit) {
		// TODO - implement Place.addExit
		throw new UnsupportedOperationException();
	}

	public HashMap<String, Exit> getMapofExit() {
		// TODO - implement Place.getMapofExit
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param otherPlace
	 */
	public Place goExit(Sting otherPlace) {
		// TODO - implement Place.goExit
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param _items
	 */
	public void setItems(HashMap<String, Items> _items) {
		// TODO - implement Place.setItems
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param name
	 * @param desc
	 * @param num
	 */
	public Place(String name, String desc, int num) {
		// TODO - implement Place.Place
		throw new UnsupportedOperationException();
	}

	public HashMap<String, Items> getListOfItems() {

	}

	public HashMap<String, SpacialObject> getListOfSO() {
		// TODO - implement Place.getListOfSO
		throw new UnsupportedOperationException();
	}

}