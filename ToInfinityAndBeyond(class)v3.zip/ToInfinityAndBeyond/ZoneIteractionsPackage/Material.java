package ToInfinityAndBeyond.ZoneIteractionsPackage;

import ToInfinityAndBeyond.SpacialPackage.*;

public class Material extends Items {

	/**
	 * 
	 * @param _quantity
	 */
	public Material(int _quantity) {
		// TODO - implement Material.Material
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisPlayer
	 */
	public void useItemOn(Player thisPlayer) {
		// TODO - implement Material.useItemOn
		throw new UnsupportedOperationException();
	}

}