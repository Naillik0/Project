package ToInfinityAndBeyond.ZoneIteractionsPackage;

import ToInfinityAndBeyond.SpacialPackage.*;

public abstract class Items {

	private final String NAME;
	private int Quantity;
	private final int PRICE;

	/**
	 * 
	 * @param thisPlayer
	 */
	public abstract void useItemOn(Player thisPlayer);

	/**
	 * 
	 * @param name
	 * @param _quantity
	 * @param price
	 */
	public Items(String name, int _quantity, int price) {
		// TODO - implement Items.Items
		throw new UnsupportedOperationException();
	}

	public String getName() {
		// TODO - implement Items.getName
		throw new UnsupportedOperationException();
	}

	public int getPrice() {
		// TODO - implement Items.getPrice
		throw new UnsupportedOperationException();
	}

	public int getQuantity() {
		// TODO - implement Items.getQuantity
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param value
	 */
	public void addQuatity(int value) {
		// TODO - implement Items.addQuatity
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param value
	 */
	public void delQuantity(int value) {
		// TODO - implement Items.delQuantity
		throw new UnsupportedOperationException();
	}

}