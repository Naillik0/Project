package ToInfinityAndBeyond.ZoneIteractionsPackage;

import ToInfinityAndBeyond.SpacialPackage.*;

public class RepairKit extends Items {

	/**
	 * 
	 * @param _quantity
	 */
	public RepairKit(int _quantity) {
		// TODO - implement RepairKit.RepairKit
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisPlayer
	 */
	public void useItemOn(Player thisPlayer) {
		// TODO - implement RepairKit.useItemOn
		throw new UnsupportedOperationException();
	}

}