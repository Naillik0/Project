package ToInfinityAndBeyond.ZoneIteractionsPackage;

import ToInfinityAndBeyond.SpacialPackage.*;

public class BarrelOfFuel extends Items {

	/**
	 * 
	 * @param thisPlayer
	 */
	public void useItemOn(Player thisPlayer) {
		// TODO - implement BarrelOfFuel.useItemOn
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param _quantity
	 */
	public BarrelOfFuel(int _quantity) {
		// TODO - implement BarrelOfFuel.BarrelOfFuel
		throw new UnsupportedOperationException();
	}

}