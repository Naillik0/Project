package ToInfinityAndBeyond.ZoneIteractionsPackage;

public class Exit {

	private final int DISTANCE;
	private Place[] NextPlace;

	public Place getNextPlace() {
		// TODO - implement Exit.getNextPlace
		throw new UnsupportedOperationException();
	}

	public void getDistance() {
		// TODO - implement Exit.getDistance
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Distance
	 * @param NextPlace
	 */
	public Exit(int Distance, Place NextPlace) {
		// TODO - implement Exit.Exit
		throw new UnsupportedOperationException();
	}

	public void getNameNextPlace() {
		// TODO - implement Exit.getNameNextPlace
		throw new UnsupportedOperationException();
	}

}