package ToInfinityAndBeyond.SpacialPackage;

public class BlasterUltime extends Weapons {

	/**
	 * 
	 * @param name
	 * @param damageDefault
	 * @param rank
	 * @param useAmm
	 * @param quant
	 * @param price
	 */
	public BlasterUltime(String name, int damageDefault, int rank, boolean useAmm, int quant, int price) {
		// TODO - implement BlasterUltime.BlasterUltime
		throw new UnsupportedOperationException();
	}

}