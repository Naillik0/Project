package ToInfinityAndBeyond.SpacialPackage;

public class Bomb extends Weapons {

	/**
	 * 
	 * @param name
	 * @param damageDefault
	 * @param rank
	 * @param useAmm
	 * @param quant
	 * @param price
	 */
	public Bomb(String name, int damageDefault, int rank, boolean useAmm, int quant, int price) {
		// TODO - implement Bomb.Bomb
		throw new UnsupportedOperationException();
	}

}