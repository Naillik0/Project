package ToInfinityAndBeyond.SpacialPackage;

public class IEM extends Weapons {

	/**
	 * 
	 * @param name
	 * @param damageDefault
	 * @param rank
	 * @param useAmm
	 * @param quant
	 * @param price
	 */
	public IEM(String name, int damageDefault, int rank, boolean useAmm, int quant, int price) {
		// TODO - implement IEM.IEM
		throw new UnsupportedOperationException();
	}

}