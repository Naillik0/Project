package ToInfinityAndBeyond.SpacialPackage;

import ToInfinityAndBeyond.ZoneIteractionsPackage.*;

public abstract class SpacialObject {

	private Shield myShield;
	private Weapons MapEquipedWeapons;
	private Storage myStorage;
	private String Name;
	private int LifePoint;
	private final int LIFEPOINTMAX;
	private int Rank;
	private Place myPlace;

	/**
	 * 
	 * @param _name
	 * @param LP
	 * @param Rank
	 */
	public SpacialObject(String _name, int LP, int Rank) {
		// TODO - implement SpacialObject.SpacialObject
		throw new UnsupportedOperationException();
	}

	public boolean is_destroy() {
		// TODO - implement SpacialObject.is_destroy
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param damage
	 */
	public void getHit(int damage) {
		// TODO - implement SpacialObject.getHit
		throw new UnsupportedOperationException();
	}

	public HashMap<String, Items> getListItems() {
		// TODO - implement SpacialObject.getListItems
		throw new UnsupportedOperationException();
	}

	public boolean haveWeaponEquip() {
		// TODO - implement SpacialObject.haveWeaponEquip
		throw new UnsupportedOperationException();
	}

}