package ToInfinityAndBeyond.SpacialPackage;

public class Enemy extends SpacialObject {

	public void loseItems() {
		// TODO - implement Enemy.loseItems
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisWeapon
	 * @param SO
	 */
	public void useWeapon(Weapons thisWeapon, SpacialObject SO) {
		// TODO - implement Enemy.useWeapon
		throw new UnsupportedOperationException();
	}

}