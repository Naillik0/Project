package ToInfinityAndBeyond;

public class Main {

	public Main() {
		// TODO - implement Main.Main
		throw new UnsupportedOperationException();
	}

}