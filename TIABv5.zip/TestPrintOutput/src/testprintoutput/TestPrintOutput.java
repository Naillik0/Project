/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testprintoutput;


import java.awt.*;

import java.io.*;

import javax.swing.JOptionPane;
import javax.swing.*;
/**
 *
 * @author Naillik
 */
public class TestPrintOutput {

  public static void main(String[] args) throws InterruptedException, IOException {
      
      JFrame frame = new JFrame();
      frame.add( new JLabel(" Console " ), BorderLayout.NORTH );
        
      JTextArea ta = new JTextArea();
      TextAreaOutputStream taos = new TextAreaOutputStream( ta, 60 );
      PrintStream ps = new PrintStream( taos );
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setAlwaysOnTop(true);//show on top
      ta.setEditable(false);//no wrtite
      
      System.setOut( ps );
      System.setErr( ps );

      
      frame.add( new JScrollPane( ta )  );

      frame.pack();
      frame.setVisible( true );
      frame.setSize(800,600);
      int reply;
      do{
          
      
      frame.setBackground(Color.yellow);
      
      
      ps.print(ColorOutput.ANSI_BLUE);
      System.out.println("test");
      System.out.println("\033[H\033[2J");
      System.out.println("test2");
      Thread.sleep( 500 );
      
      System.out.print(ColorOutput.ANSI_BLUE + ColorOutput.ANSI_BG_WHITE  +  "  TEST  ");
      System.out.println("test22");
      System.out.println("test3"); 
      System.out.println(ColorOutput.ANSI_RESET);
      Thread.sleep( 500 );
      ta.setBackground(Color.red);
      ta.setForeground(Color.green);
      System.out.println("test33");
      Thread.sleep( 500 );
      
        ta.setBackground(new Color(102, 102, 0)); //mutiple colo wth pane
      ta.setForeground(Color.YELLOW);
      System.out.println("test4");
      Thread.sleep( 500 );
      
      
      System.out.println("test5");
      Thread.sleep( 1000 );
      
      
      
      
      taos.clear(); ///efface le texte

      String test;
      test = JOptionPane.showInputDialog("input test");
      System.out.println("Your input :" + test);
      Thread.sleep( 1000 );
      reply = JOptionPane.showConfirmDialog(null, "Want to quit", "Question", JOptionPane.YES_NO_OPTION);
      }while(reply != JOptionPane.YES_OPTION);
      System.out.println("Press Enter to continue");
      
      
      
      
      
      
      frame.dispose();//ferme 
      
     
    }

  
}


