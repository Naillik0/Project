package ToInfinityAndBeyond.ZoneIteractionsPackage;

import ToInfinityAndBeyond.SpacialPackage.*;

public class Material extends Items {
    private static final boolean isUsable = false;

    public Material(String name, int _quantity, int price) {
        super(name, _quantity, price, isUsable);
    }
    

    
    @Override
    public void useItemOn(SpacialObject thisPlayer) {
        System.out.println("this object is unusable");   
    }

}