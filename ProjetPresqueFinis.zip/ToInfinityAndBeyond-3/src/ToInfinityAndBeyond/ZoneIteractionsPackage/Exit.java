package ToInfinityAndBeyond.ZoneIteractionsPackage;

public class Exit {

	private final int DISTANCE;
	private Place NextPlace;

	public Place getNextPlace() {
		return NextPlace;
	}

	public int getDistance() {
		return DISTANCE;
	}

        public Exit(int DISTANCE, Place NextPlace) {
            this.DISTANCE = DISTANCE;
            this.NextPlace = NextPlace;
        }

	

	public String getNameNextPlace() {
		return NextPlace.getNameLocation();
	}

}