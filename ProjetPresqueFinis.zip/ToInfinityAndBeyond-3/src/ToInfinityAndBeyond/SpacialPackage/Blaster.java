package ToInfinityAndBeyond.SpacialPackage;

public class Blaster extends Weapons {

    public Blaster(String name, int damageDefault, int rank, boolean useAmm, int quant, int price) {
        super(name, damageDefault, rank, useAmm, quant, price);
    }
    
    @Override
    public void useItemOn(SpacialObject target) {
        target.getHit(this.getDamage(),1,1); // x1 sur la vie et bouclier
    }

    @Override
    public boolean haveAmmo(SpacialObject theShooter) {
        return true;
    }

}