package ToInfinityAndBeyond.SpacialPackage;

public class IEM extends Weapons {

    public IEM(String name, int damageDefault, int rank, boolean useAmm, int quant, int price) {
        super(name, damageDefault, rank, useAmm, quant, price);
    }

    @Override
    public boolean haveAmmo(SpacialObject theShooter){
        return true;
    }

    @Override
    public void useItemOn(SpacialObject target) {
        target.getHit(this.getDamage(),2,1);
    }

}