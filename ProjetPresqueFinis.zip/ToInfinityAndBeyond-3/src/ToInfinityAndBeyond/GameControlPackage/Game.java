package ToInfinityAndBeyond.GameControlPackage;

import java.util.*;
import ToInfinityAndBeyond.ZoneIteractionsPackage.*;
import ToInfinityAndBeyond.SpacialPackage.*;

public class Game {
        /*
	private GameState State = Start;
	private Collection<File<ArrayList>> ListSaveFiles;
	Place ListOfPlace;
	private Player myPlayer;
	private Action Actions;
	private GameState myState;
	private int generationSize;
	private final String[] FNAME;
	private final String[] FNAMEFORM;
	private int sizeOfMap;
	private final String FILE_TYPE = ".ftl";
	private final String FILE_SEP = System.getProperty("file.separator");
	private TextOutputForm tof;

	public Game() {
		// TODO - implement Game.Game
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param myFile
	 */
	/*public boolean loadSave(File myFile) {
		// TODO - implement Game.loadSave
		throw new UnsupportedOperationException();
	}

	public List listAllSave() {
		// TODO - implement Game.listAllSave
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param saveFile
	 */
	/*public void deleteSave(File saveFile) {
		// TODO - implement Game.deleteSave
		throw new UnsupportedOperationException();
	}

	public void newSave() {
		// TODO - implement Game.newSave
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param fileName
	 */
	public void NewGame(String fileName) {
		// TODO - implement Game.NewGame
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param sizeOption
	 */
	public void generateMap(String sizeOption) {
		// TODO - implement Game.generateMap
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param number
	 */
	public int randomInt(int number) {
		// TODO - implement Game.randomInt
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param name
	 */
	public String getFormOfPlace(String name) {
		// TODO - implement Game.getFormOfPlace
		throw new UnsupportedOperationException();
	}

	public int getMaxPlanetOfList() {
		// TODO - implement Game.getMaxPlanetOfList
		throw new UnsupportedOperationException();
	}

	public void drawMap() {
		// TODO - implement Game.drawMap
		throw new UnsupportedOperationException();
	}

	public String getDrawMap() {
		// TODO - implement Game.getDrawMap
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param str
	 */
	public boolean isInt(String str) {
		// TODO - implement Game.isInt
		throw new UnsupportedOperationException();
	}
        
}