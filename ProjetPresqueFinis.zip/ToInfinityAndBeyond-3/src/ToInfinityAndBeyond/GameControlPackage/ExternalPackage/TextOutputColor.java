package ToInfinityAndBeyond.GameControlPackage.ExternalPackage;

import ToInfinityAndBeyond.GameControlPackage.*;

public class TextOutputColor extends Game {

	private String RED;
	private String BLUE;
	private String Etc;

}