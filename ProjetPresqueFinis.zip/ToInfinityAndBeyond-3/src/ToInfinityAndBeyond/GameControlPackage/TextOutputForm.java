package ToInfinityAndBeyond.GameControlPackage;

import ToInfinityAndBeyond.GameControlPackage.ExternalPackage.*;

public class TextOutputForm extends TextOutputColor {

	private int SIZEOFSCREEN = 130;
/*
	public TextOutputForm() {
		// TODO - implement TextOutputForm.TextOutputForm
		throw new UnsupportedOperationException();
	}
*/
	public void PrintText(String s) {
		// TODO - implement TextOutputForm.PrintText
		          System.out.println(s);
	}
/*
	public void PrintTitle() {
		// TODO - implement TextOutputForm.PrintTitle
		throw new UnsupportedOperationException();
	}

	public void PrintCharPicture() {
		// TODO - implement TextOutputForm.PrintCharPicture
		throw new UnsupportedOperationException();
	}

	public void PrintUDLigne() {
		// TODO - implement TextOutputForm.PrintUDLigne
		throw new UnsupportedOperationException();
	}

	public void PrintMidLigne() {
		// TODO - implement TextOutputForm.PrintMidLigne
		throw new UnsupportedOperationException();
	}

	public void PrintActions() {
		// TODO - implement TextOutputForm.PrintActions
		throw new UnsupportedOperationException();
	}
        */

}