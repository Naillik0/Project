/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weapon;

/**
 *
 * @author thomascantonny
 */
public class Blaster extends Weapon{

    public Blaster(String type, int DAMAGE, int ammo, int rank, String name, int quantity, int price, boolean USABLE) {
        super(type, DAMAGE, ammo, rank, name, quantity, price, USABLE);
    }

    



    
    @Override
    public void upgrade(){
        //prix a gerer
        this.rank ++;
        this.DAMAGE = this.DAMAGE*2;
        
    }   

    @Override
    public void shoot(SpacialObject s){
        int damage;
        if(s.shield.isActif()){
            damage = s.shield.decreaseEnergy(this.DAMAGE);
            s.takeDamage(damage);
            s.IsDestroy();
        }
        else{
            s.takeDamage(this.DAMAGE);
            s.IsDestroy();  
        }
        
    }


}
