/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weapon;

import java.util.HashMap;

public class SpacialObject implements textOutPutForm{
    private final String NAME;

    protected int hp;
    private int max_hp = 20;
    private int rank;
    protected HashMap<Integer,Weapon> tabWeapons ;
    protected Storage inventory;
    protected Shield shield;

    public SpacialObject(String NAME, int hp, int rank, HashMap<Integer, Weapon> tabWeapons, Storage inventory, Shield shield) {
        this.NAME = NAME;
        this.hp = hp;
        this.rank = rank;
        this.tabWeapons = tabWeapons;
        this.inventory = inventory;
        this.shield = shield;
    }

 
    public Storage getInventory() {
        return inventory;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public int getMax_hp() {
        return max_hp;
    }

    public void setMax_hp(int max_hp) {
        this.max_hp = max_hp;
    }

    
    
    public void takeDamage(int d){
        shield.decreaseEnergy(d);
        
        this.hp -=d;
        afficheText(this.NAME + "lose :  " + d + " life point");
    }
    
    public boolean IsDestroy(){
        if(this.hp <= 0){
            afficheText(this.NAME +" is destroy");
            return true;
        }
        else{
            return false;
        } 
    }

    @Override
    public void afficheText(String s) {
        System.out.println("s");
            }
} 
