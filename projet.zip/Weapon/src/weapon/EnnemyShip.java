/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weapon;

import java.util.HashMap;

/**
 *
 * @author thomascantonny
 */
public class EnnemyShip extends SpacialObject implements Shoot{

    public EnnemyShip(String NAME, int hp, int rank, HashMap<Integer, Weapon> tabWeapons, Storage inventory, Shield shield) {
        super(NAME, hp, rank, tabWeapons, inventory, shield);
    }

 
    
    public HashMap<String,Items> getListItem(){
        return this.inventory.getListOfItems();
    }

    @Override
    public void useWeapon(HashMap<Integer, Weapon> tabWeapons, SpacialObject target) {
        Weapon weapon = this.tabWeapons.get(1);
        weapon.shoot(target);
    }
}
