/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weapon;

import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author thomascantonny
 */
public class Player extends SpacialObject implements Shoot, textOutPutForm {
    
    private final static int priceUpgrade = 20;

    public Player(String NAME, int hp, int rank, HashMap<Integer, Weapon> tabWeapons, Storage inventory, Shield shield) {
        super(NAME, hp, rank, tabWeapons, inventory, shield);
    }

   
    
    public int getHp() {
        return hp;
    }

    public void addLife(int hp) {
        this.hp += hp;
    }

    //havethisitem a faire
    
    public void useThisItem(String name){
        if(this.haveThisItem(name)){
            HashMap<String,Items> liste = this.inventory.getListOfItems();
            Items i = liste.get(name);
            if(!(i instanceof Weapon)){
                Items.useItemOn(this);
                i.addQuantity(-1);
                liste.replace(name, i);
                inventory.refresh(liste);
                this.inventory = this.getInventory();
            }
            else
                afficheText("A weapon can only be <equipWeapon> or <unequipWeapon>. ");
        }
        else
            afficheText("You don't have this item.");
    }
    
    public boolean haveThisItem(String name){
        HashMap<String,Items> liste = this.inventory.getListOfItems();
        return liste.containsKey(name);
    }
    
    
    public void upRank(){
        if(this.getRank() < 2){
            HashMap<String,Items> Liste = inventory.getListOfItems();
            Items money = Liste.get("money");
            if(money.getQuantity() < priceUpgrade){
                afficheText("Not enought money to upgrage your Spaceship");
            }
            else{
                afficheText("Your Spaceship is level 2");
                this.setRank(2); 
                this.setMax_hp(40);
                money.setQuantity(money.getQuantity()-priceUpgrade);
            }
        }
        else{
            afficheText("Your SpaceShip is already lvl max !"); //interface
        }
    }
        
    
    public void equipWeapon(Weapon w){
        if(tabWeapons.size() < 2){
            tabWeapons.put(tabWeapons.size() + 1, w);
        }
        else{
            Scanner scan = new Scanner(System.in);
            for(int i = 1; i < tabWeapons.size(); i++){
                afficheText(i + "You have :" + tabWeapons.get(i).getName()); //interface

            }
            int answer = scan.nextInt();
            while(answer != 1 || answer != 2){
            afficheText("Quelle arme voulez-vous désequiper ? "); //interface
            answer = scan.nextInt();
            }
            tabWeapons.remove(answer);
            tabWeapons.put(answer, w);
        }
    }
    
    public void unequipWeapon(){
        Scanner scan = new Scanner(System.in);
        for(int i = 1; i < tabWeapons.size(); i++){
            afficheText(i + "You have :" + tabWeapons.get(i).getName());
           
        }
        int answer = scan.nextInt();
        while(answer != 1 || answer != 2){
        afficheText("Quelle arme voulez-vous désequiper ? "); //inteface
        answer = scan.nextInt();
        }
        tabWeapons.remove(answer);     
    }   
    
    
    @Override
    public void useWeapon(HashMap<Integer, Weapon> tabWeapons,SpacialObject target){
        if(!target.IsDestroy()){
            Scanner scan = new Scanner(System.in);
            for(int i = 1; i < tabWeapons.size(); i++){
                afficheText(i + "You have :" + tabWeapons.get(i).getName()); //interface

            }
            int answer;
            answer = 0;
            while(answer != 1 || answer != 2){
            afficheText("Wich weapon do-you want to use ? "); //interface
            answer = scan.nextInt();
            }
            Weapon w = tabWeapons.get(answer);
            w.shoot(target);
        }
        else
            afficheText("There is no target."); //interface
    }
    
    public void doAction(String action){ 
        String split[] = action.split(" ",2);
        HashMap<String,Items> liste = this.inventory.getListOfItems();
        switch(split[0]){
            case "GO":
                //a faire avec la map
                break;
            
            case "USE":
                this.useThisItem(split[1]);
                break;
                
            case "LOOK": // Look exit or search
                // a faire avec la map
                break;
                /*
            case "TAKE":
                String item;
                //Items item = map.get(split[1])
                Items i;
                liste.put(split[1],i); //item
                i.addQuantity(+1);
                inventory.refresh(liste);
                this.inventory = this.getInventory();
                break;
                */
                
            case "ATTACK":
                //SpacialObject target = map.getTarget(split[1]);
                //if(target == NULL)
                    //afficheTexte("Cible invalide");
                //else
                    //this.useWeapon(this.tabWeapons,target);
                break;
                
            case "QUIT":
                
                System.exit(0);//pas sûr
                //a faire avec game
                break;
                
            case "DROP": //comme delete
                Items item2 = liste.get(split[1]);
                this.inventory.deleteItem(item2);
                break;
                
            case "HELP": //vraiment utile ?
                //a faire liste des commandes avec l'interface affichage
                break;
                
            case "Upgrade":
                this.upRank();
                break;
              
            default : 
                System.out.println("");
                break;
                
        }
        
    
          
    }

    @Override
    public void afficheText(String s) {
        System.out.println("s");
    }
        
}
