/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weapon ;

/**
 *
 * @author thomascantonny
 */
public class Bombe extends Weapon {

    public Bombe(String type, int DAMAGE, int ammo, int rank, String name, int quantity, int price, boolean USABLE) {
        super(type, DAMAGE, ammo, rank, name, quantity, price, USABLE);
    }

    

    @Override
    public void shoot(SpacialObject s) {
        if(this.ammo != 0){
            this.ammo --;
            s.takeDamage(this.DAMAGE); 
            
        }
        else
            System.out.println("You need ammo to use this weapon !");
    }


    @Override
    public void upgrade() {
        this.rank ++;
        this.DAMAGE = this.DAMAGE*2;
    }


}
