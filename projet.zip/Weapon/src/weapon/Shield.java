/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weapon;

/**
 *
 * @author thomascantonny
 */
public class Shield {
    private int energy;
    private final int shieldMaxEnergy;
    private boolean actif;

    public Shield(int shieldMaxEnergy, boolean actif) {
        this.energy = shieldMaxEnergy;
        this.shieldMaxEnergy = shieldMaxEnergy;
        this.actif = actif;
    }

    public void activeShield(){
        this.actif = true;
    }
    
    public void desactiveShield(){
        this.actif = false;
    }
    
    public int decreaseEnergy(int value){
        int restOfDamage = 0;
        if(this.actif){
            if(this.energy - value > 0){
                this.energy -= value; 
                return restOfDamage;
            }
            else{
                this.desactiveShield();
                restOfDamage = value - this.energy;
                return restOfDamage;
                }
        }
        else{
            return(value);
        }
    }

    public int getEnergy() {
        return energy;
    }
    
    public void resetEnergy(){
        this.energy = this.shieldMaxEnergy;
    }

    public boolean isActif() {
        return actif;
    }

    
}
