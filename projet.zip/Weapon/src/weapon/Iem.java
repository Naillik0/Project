/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weapon;

/**
 *
 * @author thomascantonny
 */
public class Iem extends Weapon {

    public Iem(String type, int DAMAGE, int ammo, int rank, String name, int quantity, int price, boolean USABLE) {
        super(type, DAMAGE, ammo, rank, name, quantity, price, USABLE);
    }



        
    @Override
    public void upgrade(){
        //prix a gerer
        this.rank ++;
        this.DAMAGE = this.DAMAGE*2;
        
    }
    

    @Override
    public void shoot(SpacialObject s){ //L'iem ne fait pas de degat a la coque
        if(s.shield.isActif()){
            int damage;
            damage = s.shield.decreaseEnergy(this.DAMAGE*2);
        }        
    }
}
