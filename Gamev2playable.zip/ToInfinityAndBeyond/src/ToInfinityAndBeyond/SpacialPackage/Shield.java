package ToInfinityAndBeyond.SpacialPackage;

import java.io.Serializable;

public class Shield implements Serializable{

    //CONSTANT
        private final int ENERGYMAX;
    //VARIABLE
	private boolean Actif;
	private int Energy;
	
    //BUILDER
	public Shield(boolean actif,int maxEnergy) {
            this.Actif = actif;
            this.Energy = maxEnergy;
            this.ENERGYMAX=maxEnergy;
	}
    
    //METHOD
	public void ActivateShield() {
            this.Actif=true;
	}

	public void DesactivateShield() {
            this.Actif=false;
	}

	public int getEnergy() {
            return this.Energy;
	}

	public int DecreaseEnergy(int value){
            if(!Actif){
                return value;
            }else{
                if(Energy>=value){
                    Energy-=value;
                    if(Energy==0){
                        DesactivateShield();
                    }
                    return 0;
                }else{
                    value-=Energy;
                    Energy=0;
                    DesactivateShield();
                    return value;
                }
                
            }
            
	}

	public void ResetEnergy(){
            this.Energy=ENERGYMAX;
	}

    public int getEnergyMax() {
        return this.ENERGYMAX;
    }

}