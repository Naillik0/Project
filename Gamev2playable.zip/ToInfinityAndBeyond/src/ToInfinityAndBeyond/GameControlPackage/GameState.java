package ToInfinityAndBeyond.GameControlPackage;

public enum GameState {
	Start,
	Selection,
	Area,
	New,
	Win,
	GameOver,
	Quit,
	End
}