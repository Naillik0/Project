package ToInfinityAndBeyond.ZoneIteractionsPackage;

import ToInfinityAndBeyond.SpacialPackage.*;
import java.io.Serializable;

public abstract class Items implements Cloneable, Serializable{
        
//CONSTANT
    private final String NAME;
    private final int PRICE;
    private final boolean isUsable;
//VARIABLE
    private int Quantity;
      
        
//BUILDER        
    public Items(String name, int _quantity, int price,boolean isUsable) {
        this.NAME = name;
        this.Quantity = _quantity;
        this.PRICE = price;
        this.isUsable = isUsable;
    }

//METHOD
    public String getName() {
	return NAME;
    }

    public int getPrice() {
    	return PRICE;
    }

    public int getQuantity() {
	return Quantity;
    }

    public boolean isIsUsable() {
        return isUsable;
    }

    
	
    public void addQuatity(int _quantity) {
        this.Quantity += _quantity;
    }

	
    public void delQuantity(int _quantity) {
        if(this.Quantity>0){
            this.Quantity -= _quantity;
        }
    }

    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }
       
    @Override
    public Object clone() throws CloneNotSupportedException
    {
        return super.clone();
    }
    public abstract void useItemOn(SpacialObject thisPlayer);
        
}