/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ToInfinityAndBeyond.GameControlPackage;

import ToInfinityAndBeyond.SpacialPackage.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

/**
 *
 * @author Naillik
 */
public class IOFileSystem {

    private final static String FILE_TYPE = ".ftl";
    private final static String FILE_SEP = System.getProperty("file.separator");
    private ArrayList<File> ListSaveFiles = new ArrayList<>();
    private TextOutputForm tof = new TextOutputForm();

    
    public boolean loadSave(File myFile) throws IOException, ClassNotFoundException {
        // TODO - implement Game.Load
        ObjectInputStream ios = null;
        try {
            FileInputStream streamIn = new FileInputStream(myFile);
            ios = new ObjectInputStream(streamIn);
            //probléme de chargement... classe
            String _name = (String)ios.readObject();
            System.out.println("oks");
            //this.sizeOfMap = (int) ios.readObject();
            oos.writeObject(thisObj.getNAME());
                    oos.writeObject(thisObj.getMax_hp());
                    oos.writeObject(thisObj.getFuelMeter());
                    oos.writeObject(thisObj.getRank());
                    if(thisObj.getMyStorage().getListItems().containsKey("CREDIT"))oos.writeObject(thisObj.getMyStorage().getListItems().get("CREDIT").getQuantity());

        } catch (IOException e) {
        } finally {
            if (ios != null) {
                ios.close();
            }
        }

        return true;
    }

    public void listAllSave() {
        // TODO - implement Game.ListAllSave
        this.ListSaveFiles.clear();
        File dir = new File(".");//. for current
        File[] directoryListing = dir.listFiles();
        if (directoryListing != null) {
            for (File child : directoryListing) {
                // Do something with child
                if (child.getName().contains(FILE_TYPE)) {
                    this.ListSaveFiles.add(child);
                }
            }
        }
        
    }

    /**
     *
     * @param saveFile
     * @return
     */
    public boolean deleteSave(File saveFile) {
        // TODO - implement Game.DeleteSave
        return saveFile.delete();
    }

    /**
     *
     * @param FileName
     * @param thisListObj
     * @param thisObj
     * @throws java.io.IOException
     */
    public void newSave(String FileName,Player thisObj) throws IOException {
        // TODO - implement Game.NewGame
        //String FilePath = FileName + FILE_TYPE;
        ObjectOutputStream oos = null;
        FileOutputStream fout = null;

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-mm-yy");//  format
        LocalDateTime now = LocalDateTime.now(); // CurrentTime
        String FilePath = FileName + "_" + dtf.format(now) + FILE_TYPE;//Name by Date;
        
        String fileRep = FilePath;
        try {
            File myFile = new File(fileRep);
            fout = new FileOutputStream(myFile);
            oos =  new ObjectOutputStream(fout);
            //System.out.println(myFile.getPath())
            
           
                    oos.writeObject(thisObj.getNAME());
                    oos.writeObject(thisObj.getMax_hp());
                    oos.writeObject(thisObj.getFuelMeter());
                    oos.writeObject(thisObj.getRank());
                    if(thisObj.getMyStorage().getListItems().containsKey("CREDIT"))oos.writeObject(thisObj.getMyStorage().getListItems().get("CREDIT").getQuantity());
                    else oos.writeObject(0);
            
            //oos.writeObject(new Exit(-5, ListPlace.get(0).get(0)));
            
            //oos.writeObject(this.sizeOfMap);
            oos.close();
            fout.close();
            tof.printLineText("Save complete --> " + FilePath);
        } catch (IOException ex) {
        } finally {
            if (oos != null) {
                oos.close();
            }
        }

    }

    ArrayList<String> getSaveFile() {
        listAllSave();
         ArrayList<String> lfile = new ArrayList<>();
        this.ListSaveFiles.forEach((save) -> {
                lfile.add(save.getName().toLowerCase().replace(FILE_TYPE, ""));
        });
        return lfile;
    }

    File getFile(int FilePos) {
        listAllSave();
        return this.ListSaveFiles.get(FilePos);
    }

}
