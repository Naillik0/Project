package ToInfinityAndBeyond.GameControlPackage;

import java.util.ArrayList;
import java.util.List;

public class TextOutputForm {

	private final int SIZEOFSCREEN = 150;
        
        
        
        private static String[][] matrixOfForm = {
            {"EnemyShip",
                "               \\.   \\.      __,-\"-.__      ./   ./\n" +
"           \\.   \\`.  \\`.-'\"\" _,=\"=._ \"\"`-.'/  .'/   ./\n" +
"            \\`.  \\_`-''      _,=\"=._      ``-'_/  .'/\n" +
"             \\ `-',-._   _.  _,=\"=._  ,_   _.-,`-' /\n" +
"          \\. /`,-',-._\"\"\"  \\ _,=\"=._ /  \"\"\"_.-,`-,'\\ ./\n" +
"           \\`-'  /    `-._  \"       \"  _.-'    \\  `-'/\n" +
"           /)   (         \\    ,-.    /         )   (\\\n" +
"        ,-'\"     `-.       \\  /   \\  /       .-'     \"`-,\n" +
"      ,'_._         `-.____/ /  _  \\ \\____.-'         _._`,\n" +
"     /,'   `.                \\_/ \\_/                .'   `,\\\n" +
"    /'       )                  _                  (       `\\\n" +
"            /   _,-'\"`-.  ,++|T|||T|++.  .-'\"`-,_   \\\n" +
"           / ,-'        \\/|`|`|`|'|'|'|\\/        `-, \\\n" +
"          /,'             | | | | | | |             `,\\\n" +
"         /'               ` | | | | | '               `\\\n" +
"                            ` | | | '\n" +
"                              ` | '"},
            
            
            //--------------------------------------
            {"AlienShip",
                "	\n" +
"                _____\n" +
"             ,-\"     \"-.\n" +
"            / o       o \\\n" +
"           /   \\     /   \\\n" +
"          /     )-\"-(     \\\n" +
"         /     ( 6 6 )     \\\n" +
"        /       \\ \" /       \\\n" +
"       /         )=(         \\\n" +
"      /   o   .--\"-\"--.   o   \\\n" +
"     /    I  /  -   -  \\  I    \\\n" +
" .--(    (_}y/\\       /\\y{_)    )--.\n" +
"(    \".___l\\/__\\_____/__\\/l___,\"    )\n" +
" \\                                 /\n" +
"  \"-._      o O o O o O o      _,-\"\n" +
"      `--Y--.___________.--Y--'\n" +
"         |==.___________.==|    \n" +
"         `==.___________.=='   "},
            
            
            
            {"EnemyWalker",
                "               ________\n" +
"          _,.-Y  |  |  Y-._\n" +
"      .-~\"   ||  |  |  |   \"-.\n" +
"      I\" \"\"==\"|\" !\"\"! \"|\"[]\"\"|     _____\n" +
"      L__  [] |..------|:   _[----I\" .-{\"-.\n" +
"     I___|  ..| l______|l_ [__L]_[I_/r(=}=-P\n" +
"    [L______L_[________]______j~  '-=c_]/=-^\n" +
"     \\_I_j.--.\\==I|I==_/.--L_]\n" +
"       [_((==)[`-----\"](==)j\n" +
"          I--I\"~~\"\"\"~~\"I--I\n" +
"          |[]|         |[]|\n" +
"          l__j         l__j\n" +
"          |!!|         |!!|\n" +
"          |..|         |..|\n" +
"          ([])         ([])\n" +
"          ]--[         ]--[\n" +
"          [_L]         [_L]\n" +
"         /|..|\\       /|..|\\\n" +
"        `=}--{='     `=}--{='\n" +
"       .-^--r-^-.   .-^--r-^-.\n" +
"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"},
            {"EnemyShooter",
                "	\n" +
"      _n____n__\n" +
"     /         \\---||--<\n" +
"    /___________\\\n" +
"    _|____|____|_\n" +
"    _|____|____|_\n" +
"     |    |    |\n" +
"    --------------\n" +
"    | || || || ||\\\n" +
"    | || || || || \\++++++++------<\n" +
"    ===============\n" +
"    |   |  |  |   |\n" +
"   (| O | O| O| O |)\n" +
"   |   |   |   |   |\n" +
"  (| O | O | O | O |)\n" +
"   |   |   |   |    |\n" +
" (| O |  O | O  | O |)\n" +
"  |   |    |    |    |\n" +
" (| O |  O |  O |  O |)\n" +
" ======================"},
            {"Satellite",
                "                }--O--{\n" +
"                  [^]\n" +
"                 /ooo\\\n" +
" ______________:/o   o\\:______________\n" +
"|=|=|=|=|=|=|:A|\":|||:\"|A:|=|=|=|=|=|=|\n" +
"^\"\"\"\"\"\"\"\"\"\"\"\"\"\"!::{o}::!\"\"\"\"\"\"\"\"\"\"\"\"\"\"^\n" +
"                \\     /\n" +
"                 \\.../\n" +
"      ____       \"---\"       ____\n" +
"     |\\/\\/|=======|*|=======|\\/\\/|\n" +
"     :----\"       /-\\       \"----:\n" +
"                 /ooo\\\n" +
"                #|ooo|#\n" +
"                 \\___/"},
            {"Zone",
                "                      .   *        .       .                       .   *        .       .       \n" +
"       *      -0-                                    *      -0-                                 \n" +
"          .                .  *       - )-              .                .  *       - )-        \n" +
"       .      *       o       .       *              .      *       o       .       *           \n" +
" o                |                            o                |                               \n" +
"           .     -O-                                    .      -O-                              \n" +
".                 |        *      .     -0-   .                 |        *      .     -0-       \n" +
"       *  o     .    '       *      .        o       *  o     .    '       *      .        o    \n" +
"              .         .        |      *                   .         .        |      *         \n" +
"   *             *              -O-          .   *             *              -O-          .    \n" +
"         .             *         |     ,               .             *         |     ,          \n" +
"                .           o                                       .   *        .       .      \n" +
"        .---.                                  o                |                            o  \n" +
"  =   _/__~0_\\_     .  *            o       ' .     *             *              -O-          . \n" +
" = = (_________)             .                           .     -O-                              \n" +
"                 .                        *   .                 |        *      .     -0-   .   \n" +
"       *               - ) -       *                                .         .        |      * \n" +
""},
            {"Final",
                "           .          .\n" +
" .          .                  .          .              .\n" +
"       +.           _____  .        .        + .                    .\n" +
"   .        .   ,-~\"     \"~-.                                +\n" +
"              ,^ ___         ^. +                  .    .       .\n" +
"             / .^   ^.         \\         .      _ .\n" +
"            Y  l  o  !          Y  .         __CL\\H--.\n" +
"    .       l_ `.___.'        _,[           L__/_\\H' \\\\--_-          +\n" +
"            |^~\"-----------\"\"~ ^|       +    __L_(=): ]-_ _-- -\n" +
"  +       . !                   !     .     T__\\ /H. //---- -       .\n" +
"         .   \\                 /               ~^-H--'\n" +
"              ^.             .^            .      \"       +.\n" +
"                \"-.._____.,-\" .                    .\n" +
"         +           .                .   +                       .\n" +
"  +          .             +                                  .\n" +
"         .             .      .       \n" +
"                                                        ."},
            {"Moon",
                "o                     __...__     *               \n" +
"              *   .--'    __.=-.             o\n" +
"     |          ./     .-'     \n" +
"    -O-        /      /   \n" +
"     |        /    '\"/               *\n" +
"             |     (@)     \n" +
"            |        \\                         .\n" +
"            |         \\\n" +
" *          |       ___\\                  |\n" +
"             |  .   /  `                 -O-\n" +
"              \\  `~~\\                     |\n" +
"         o     \\     \\            *         \n" +
"                `\\    `-.__           .  \n" +
"    .             `--._    `--'jgs\n" +
"                       `---~~`                *\n" +
"            *                   o"},
            {"Home",
                "             )                              (\n" +
"            (                                 )\n" +
"    ________[]_                              []\n" +
"   /^=^-^-^=^-^\\                   /^~^~^~^~^~^~\\\n" +
"  /^-^-^-^-^-^-^\\                 /^ ^ ^  ^ ^ ^ ^\\\n" +
" /__^_^_^_^^_^_^_\\               /_^_^_^^_^_^_^_^_\\\n" +
"  |  .==.       |       ___       |        .--.  |\n" +
"^^|  |LI|  [}{] |^^^^^ /___\\ ^^^^^|  [}{]  |[]|  |^^^^^\n" +
"&&|__|__|_______|&&   .\" | \".   88|________|__|__|888\n" +
"     ====             (o_|_o)              ====\n" +
"      ====             u   u              ===="},
            
            
            {"Asteroid",
                            "         ___---___                    \n" +
            "      .--         --.      \n" +
            "    ./   ()      .-. \\.\n" +
            "   /   o    .   (   )  \\\n" +
            "  / .            '-'    \\         \n" +
            " | ()    .  O         .  |      \n" +
            "|                         |      \n" +
            "|    o           ()       |\n" +
            "|       .--.          O   |            \n" +
            " | .   |    |            |\n" +
            "  \\    `.__.'    o   .  /    \n" +
            "   \\                   /                   \n" +
            "    `\\  o    ()      /'               \n" +
            "      `--___   ___--'\n" +
            "            ---"},
            {"Planet",
            "    ,-:` \\;',`'-, \n" +
            "  .'-;_,;  ':-;_,'.\n" +
            " /;   '/    ,  _`.-\\\n" +
            "| '`. (`     /` ` \\`|\n" +
            "|:.  `\\`-.   \\_   / |\n" +
            "|     (   `,  .`\\ ;'|\n" +
            " \\     | .'     `-'/\n" +
            "  `.   ;/        .'\n" +
            "    `'-._____."},
            {"Meteor","                    |\n" +
"                    |   .\n" +
"             `.  *  |     .'\n" +
"               `. ._|_* .'  .\n" +
"             . * .'   `.  *\n" +
"          -------|     |-------\n" +
"             .  *`.___.' *  .\n" +
"                .'  |* `.  *\n" +
"              .' *  |  . `.\n" +
"                  . |\n" +
"                    |"},
            {"Boss",""},
            {"Boss2",""},
            {"intro",
"__      __   _                    _        _   _                                  _\n" +
"\\ \\    / /__| |__ ___ _ __  ___  (_)_ _   | |_| |_  ___   __ _ __ _ _ __  ___    (_)\n" +
" \\ \\/\\/ / -_) / _/ _ \\ '  \\/ -_) | | ' \\  |  _| ' \\/ -_) / _` / _` | '  \\/ -_)    _	\n" +
"  \\_/\\_/\\___|_\\__\\___/_|_|_\\___| |_|_||_|  \\__|_||_\\___| \\__, \\__,_|_|_|_\\___|   (_)\n" +
"                                                         |___/\n"},
            {"splashScreen",
"                                                                        |             Potiers L3 Informatique  12/2019\n" +
" _______      _____        __ _       _ _                               |              __\n" +
"|__   __|    |_   _|      / _(_)     (_) |                              |   .-.__      \\ .-.  ___  __\n" +
"   | | ___     | |  _ __ | |_ _ _ __  _| |_ _   _                       |   |_|  '--.-.-(   \\/\\;;\\_\\.-._______.-.\n" +
"   | |/ _ \\    | | | '_ \\|  _| | '_ \\| | __| | | |                      |   (-)___     \\ \\ .-\\ \\;;\\(   \\       \\ \\\n" +
"   | | (_) |  _| |_| | | | | | | | | | | |_| |_| |                      |    Y    '---._\\_((Q)) \\;;\\\\ .-\\     __(_)\n" +
"   |_|\\___/  |_____|_| |_|_| |_|_| |_|_|\\__|\\__, |                      |    I           __'-' / .--.((Q))---'    \\,\n" +
"                                             __/ |                      |    I     ___.-:    \\|  |   \\'-'_          \\\n" +
"                                            |___/                       |    A  .-'      \\ .-.\\   \\   \\ \\ '--.__     '\\\n" +
"                            _   ____                             _      |    |  |____.----((Q))\\   \\__|--\\_      \\     '\n" +
"            /\\             | | |  _ \\                           | |     |       ( )        '-'  \\_  :  \\-' '--.___\\\n" +
"           /  \\   _ __   __| | | |_) | ___ _   _  ___  _ __   __| |     |        Y                \\  \\  \\       \\(_)\n" +
"          / /\\ \\ | '_ \\ / _` | |  _ < / _ \\ | | |/ _ \\| '_ \\ / _` |     |        I                 \\  \\  \\         \\,\n" +
"         / ____ \\| | | | (_| | | |_) |  __/ |_| | (_) | | | | (_| |     |        A                   \\  \\  \\          '\\\n" +
"        /_/    \\_\\_| |_|\\__,_| |____/ \\___|\\__, |\\___/|_| |_|\\__,_|     |        |                    \\  \\__|           '\n" +
"                                             _/ |                       |                              \\_:.  \\\n" +
"                                            |___/                       |                                \\ \\  \\\n" +
"                                                                        |                                 \\ \\  \\\n" +
"                                                                        |                                  \\_\\_|\n" +
"                                                                        |\n"},
            {"outro",
                " ___                               _              _             _            _   \n" +
"| _ \\_ _ ___ ______  __ _ _ _ _  _| |_____ _  _  | |_ ___    __| |_ __ _ _ _| |_ \n" +
"|  _/ '_/ -_|_-<_-< / _` | ' \\ || | / / -_) || | |  _/ _ \\  (_-<  _/ _` | '_|  _|\n" +
"|_| |_| \\___/__/__/ \\__,_|_||_\\_, |_\\_\\___|\\_, |  \\__\\___/  /__/\\__\\__,_|_|  \\__|\n" +
"                              |__/         |__/           \n"}
        };
                

    //**********Ligne Haut et Bas*************//
    public void printLineExt(){
        String line = "";
        for(int i = 0;i<SIZEOFSCREEN;i++){line= line + "_";}
        System.out.println(line);
    }
    //**********Millieu*************//
    public void printLineMid(){
        String line = "";
        for(int i = 0;i<SIZEOFSCREEN;i++){line= line + "-";}
        System.out.println(line);
    }
    //**********Coté + vide*************//
    public void printLineWall(){
        String line = "|";
        for(int i = 0;i<SIZEOFSCREEN-1;i++){
           
            if(i<SIZEOFSCREEN-2)line= line + " ";else line= line + "|";
        }
        System.out.println(line);
    }
    
    
    //**********Imprime un dessin*************//
    public void printFormText(String form){
        String text = "";
        for(int numLine=0; numLine < CountLine(form) ; numLine++){
            text +="|";
            String lineform = ReturnLine(form,numLine);
            String addText = "   "+ lineform;
            text += addText;
            int beginSize = addText.length()+2;//+\0 or \n
            for(int i = 0;i<SIZEOFSCREEN-beginSize;i++){
               text = text + " ";
            }   
            text +="|\n";
        }
        System.out.print(text);
    }
    //**********Imprime un texte*************//
    public void printLineText(String myText){
        String text = "|";
        String addText = " "+ myText;
        text += addText;
        int beginSize = addText.length()+2;//+\0 or \n
        for(int i = 0;i<SIZEOFSCREEN-beginSize;i++){
            text = text + " ";
            }   
        text +="|";
        
        System.out.println(text);
    }
    //**********Imprime des actions *************//
    public void printLineAction(List<String> ListAction){
        
        
        
        
        String text = "|";
        for(int numAction = 0;numAction < ListAction.size();numAction++)
        {
            //text += " " + numAction + " : " + ListAction.get(numAction) + " |";
            text += " "+ ListAction.get(numAction) + " |";
        }
        int beginSize = text.length()+2;//+\0 or \n
        for(int i = 0;i<SIZEOFSCREEN-beginSize;i++){
            text = text + " ";
            }   
        text +=" |";
        
        
        printLineMid();
        printLineWall();
        System.out.println(text);
        printLineWall();
        printLineMid();
        
    }
    //**********Imprime des actions + numero *************//
       public void printLineActionNum(List<String> ListAction){
        String text = "";
        for(int numAction = 0;numAction < ListAction.size();numAction++)
        {
            String addText = "| "+ numAction + " : "+ListAction.get(numAction);
            text += addText;
            int beginSize = addText.length()+2;//+\0 or \n
            for(int i = 0;i<SIZEOFSCREEN-beginSize;i++){
                text = text + " ";
                }   
            text +=" |\n";
        }
        System.out.print(text);
    }
    //**********Imprime la carte*************//
       public void printLineMap(ArrayList[][] mapGrid){
        String text = "| Y/X ";
        
        for(int _i = 0;_i < SIZEOFSCREEN;_i++)//ligne YX 123->
        {
            text+= "    " + _i + "  ";
        }
        text+="         |\n";
        for(int _x = 0;_x < SIZEOFSCREEN;_x++)
        {
            String addText ="| " + _x + "  ";
            text += addText;
            
            for(int _y = 0;_y < SIZEOFSCREEN;_y++)
            {   
                /*if(mapGrid[_x][_y] != null)
                {

                }
                else
                {


                }*/
                
                if(_x<10)
                {
                    if((int)(Math.random() * (5 + 1))<1)text = text + " O   ";
                    else text = text + "    ";
                }else 
                {
                    if((int)(Math.random() * (5 + 1))<1)text = text + "  x ";
                    else text = text + "  ";
                }
            
            }
            //if(_x<10)text = text + " ";
            text +="|\n";
        }
        System.out.print(text);
    }   
       
       
       
    
    //**********Comptage ligne dans texte*************//
    public int CountLine(String txt)
    {
        int number = 0;
        for(int pos = 0;pos<txt.length();pos++)
        {
            if("\n".equals(txt.substring(pos, pos+1)))
            {
                number++;
            }
        }
        return number;
    } 
    
    //**********Retourn une ligne du texte*************//
    public String ReturnLine(String txt,int Line)
    {
        
        int number = 0;
        int pos;
        for(pos = 0;pos<txt.length();pos++) // jusqua la bonne ligne
        {
            
            if(number == Line){
                if(Line!=0)pos++;
                break;
            }
            
            if("\n".equals(txt.substring(pos, pos+1)))
            {
                number++;
                
            }
            
        }
        
        int Linesize = 0;
        for(;pos<txt.length();pos++)
        {
            if("\n".equals(txt.substring(pos, pos+1)))
            {
                break;
            }
            Linesize++;
        }
        if(Line ==0)return txt.substring(0, pos).replaceAll("\n", "");
        else return txt.substring(pos-1-Linesize, pos).replaceAll("\n", "");
    } 

    public String getForm(String formSearch) {
        for(String[] form : matrixOfForm)
        {
            if(form[0].equals(formSearch))return form[1];
        }
        return "Unknow form";
    }

}