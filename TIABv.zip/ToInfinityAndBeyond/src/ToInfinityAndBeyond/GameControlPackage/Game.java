package ToInfinityAndBeyond.GameControlPackage;

//Alt + Shift + F auto indent
import ToInfinityAndBeyond.ZoneIneractionsPackage.BarrelOfFuel;
import ToInfinityAndBeyond.ZoneIneractionsPackage.RepairKit;
import ToInfinityAndBeyond.ZoneIneractionsPackage.Place;
import ToInfinityAndBeyond.ZoneIneractionsPackage.Ammo;
import static ToInfinityAndBeyond.GameControlPackage.GameState.Start;
import java.util.*;
import ToInfinityAndBeyond.SpacialPackage.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class Game {

    private GameState State = Start;
    private ArrayList<ArrayList<Place>> ListPlace = new ArrayList<>();
    private Player myPlayer;
    private final String[] FNAME = {"Planet", "Zone", "Asteroid", "Satellite", "Moon"};
    private final String[] FNAMEFORM = {"  O  ", "  *  ", "  °  ", " -o- ", "  C  "};
     private  TextOutputForm tof = new TextOutputForm();//Object afficheur
    private MapGeneration mg;
    private IOFileSystem iofs = new IOFileSystem();

    public Game() throws InterruptedException, IOException, CloneNotSupportedException, ClassNotFoundException {
        // TODO - implement Game.Game
       

        Scanner scan = new Scanner(System.in);//cration du scanner

        String answer = null; // mémorisation de la réponse
        int numPreviousPlace = -1;

        //File file = new File("C:/Users/Me/Desktop/directory/file.txt");
        //file.getParentFile().mkdirs();dossiert
        //Listing des actions
        ArrayList<String> listAction = new ArrayList<>();
        HashMap<String,SpacialObject> ListEnemy = null;
        for (Action val : Action.values()) {
            listAction.add(val.name());
        }
        listAction.add("RESET");
        do {

            if (myPlayer != null && myPlayer.is_destroy()) {
                this.State = GameState.GameOver;
            }

            switch (this.State) {
                //----------------------------------------------------------------------------------------------------------
                case Start:

                    tof.printLineText("Tips : Maximize your terminal for a better game experience");
                    tof.printLineText("(Press anyKey to continue ...)");
                    System.in.read();//waitinput
                    tof.printFormText(tof.getForm("intro"));
                    tof.printLineMid();
                    //Thread.sleep(1000);
                    tof.printFormText(tof.getForm("splashScreen"));
                    tof.printLineMid();
                    //Thread.sleep(2000);
                    tof.printFormText(tof.getForm("outro"));

                    tof.printLineMid();

                    System.in.read();//waitinput
                    tof.printFormText("This game is a Sci-Fi adventure in space.\n"
                            + "You will travel in different place to find elements to collect.\n"
                            + "you can also, upgrade your ship,attack object or enemy...\n"
                            + "Try to do and find a maximum of things and get a bigger highScore.\n"
                            + "Use at any time the command HELP and MAP, if you are lost.\n"
                            + "It will help you for playing the game.\n"
                            + "Good luck.");

                    tof.printLineMid();
                    Thread.sleep(1000);
                    tof.printLineText("Do you want to begin a new game or select a game saved");
                    tof.printLineText("(Enter NEW or SEL to begin)");
                    answer = scan.nextLine();//if(st == null)throw new NullPointerException();
                    if (answer == null) {
                        throw new NullPointerException();
                    }
                    /*Verification */
                    while (!"NEW".equalsIgnoreCase(answer) && !"SEL".equalsIgnoreCase(answer)) {
                        tof.printLineText("Action not reconize");
                        answer = scan.nextLine();
                    }

                    //Selon la réponse
                    if ("NEW".equalsIgnoreCase(answer)) {
                        this.State = GameState.New; //Generate new map player ...
                    } else {
                        tof.printLineText("Loading list of save :");
                        
                        ArrayList<String> listS = this.iofs.getSaveFile();
                        
                        if (listS.isEmpty()) {
                            tof.printLineText("No save find");
                            tof.printLineText("Generating a new game...");
                            this.State = GameState.New;
                        } else {
                            this.State = GameState.Selection; //Get in game
                        }
                    }
                    break;
                case New:

                    //new list
                    ListPlace = new ArrayList<>();

                    //generateMap
                    tof.printLineText("Enter the size of the map");
                    tof.printLineText("(SMALL, MEDIUM or BIG)");
                    answer = scan.nextLine();
                    while (!"SMALL".equalsIgnoreCase(answer) && !"MEDIUM".equalsIgnoreCase(answer) && !"BIG".equalsIgnoreCase(answer)) {
                        tof.printLineText("Command unvalide ");
                        answer = scan.nextLine();
                    }
                    mg = new MapGeneration(answer);
                    ListPlace = mg.getMap();
                    //see genartion of map
                    /*ListPlace.forEach((list) -> {
                        String ln = "";
                        for (Place plac : list) {
                            ln += (plac.getNameLocation() + " ");//+ plac.getNum()+"-->"+plac.getExit()+"|||");
                        }
                        tof.printLineText(ln);
                    });
*/
                    drawMap();//print map

                    /**
                     * *-------------------------------------------------------------*
                     */
                    tof.printLineText("Enter player name");
                    String PlayerName = scan.nextLine();
                    while ("".equalsIgnoreCase(PlayerName)) {
                        tof.printLineText("Name unvalide ");
                        PlayerName = scan.nextLine();
                    }
                    tof.printLineText(PlayerName);

                    Place begin = ListPlace.get(0).get(0);

                    HashMap<Integer, Weapons> initTabWeapons = new HashMap<>();
                    initTabWeapons.put(1, new Lazer());
                    initTabWeapons.put(2, new Bomb());
                    
                    
                    Storage bag = new Storage(20);
                    bag.addItem(new Ammo(10));
                    bag.addItem(new RepairKit(2));
                    bag.addItem(new BarrelOfFuel(2));
                    //Player(String name, int hp, int rank, HashMap<Integer, Weapons> tabWeapons, Storage inventory, Shield shield, int _fuelMeter,TextOutputForm _tof)
                    this.myPlayer = new Player(PlayerName, 20, 1, initTabWeapons, bag, new Shield(true, 15), 10, tof);
                    this.myPlayer.setMyPlace(begin);
                    this.State = GameState.Area; //Get in game

                    break;
                case Selection:

                    tof.printLineText("Type the file or number to load ");
                    tof.printLineText("Type DEL before file to delete it ");
                    tof.printLineText("(Or type NEW to make a new file)");
                    ArrayList<String> saveList = new ArrayList<>();
                    iofs.listAllSave();//update base
                    saveList = iofs.getSaveFile();//get all name
                    tof.printLineActionNum(saveList);

                    answer = scan.nextLine();//if(st == null)throw new NullPointerException();
                    if (answer == null) {
                        throw new NullPointerException();
                    }
                    /*Verification */
                    boolean acceptNumber = false;
                    if (isInt(answer)) {
                        if (Integer.parseInt(answer) < saveList.size()) {
                            acceptNumber = true;
                        }
                    }

                    while (!"NEW".equalsIgnoreCase(answer) && !saveList.contains(answer.toLowerCase())
                            && !acceptNumber) {
                        tof.printLineText("-----File not reconize----");
                        tof.printLineText("Type the file or number to load ");
                        tof.printLineText("Type DEL before file to delete it ");
                        tof.printLineText("(Or type NEW to make a new file)");
                        answer = scan.nextLine();
                        if (isInt(answer)) {
                            if (Integer.parseInt(answer) < saveList.size()) {
                                acceptNumber = true;
                            }
                        }
                    }
                    int FilePos;
                    if (acceptNumber) {
                        FilePos = Integer.parseInt(answer);
                    } else {
                        FilePos = saveList.indexOf(answer);
                    }
                    tof.printLineText("Your selection : " + answer + " --> " + this.iofs.getFile(FilePos).getName());

                    if ("NEW".equalsIgnoreCase(answer)) {
                        this.State = GameState.New; //Generate new map player ...
                    } else {
                        tof.printLineText("Do you want to load or delete file");
                        tof.printLineText("(Type LOAD or DEL)");
                        answer = scan.nextLine();//if(st == null)throw new NullPointerException();
                        while (!"DEL".equalsIgnoreCase(answer) && !"LOAD".equalsIgnoreCase(answer)) {
                            answer = scan.nextLine();
                            tof.printLineText("-----Command not reconized----");
                            tof.printLineText("Do you want to load or delete file");
                            tof.printLineText("(Type LOAD or DEL)");
                        }

                        if ("DEL".equalsIgnoreCase(answer)) {
                            boolean ok = this.iofs.deleteSave(this.iofs.getFile(FilePos));
                            if (!ok) {
                                tof.printLineText("Error while deleting file");
                            } else {
                                tof.printLineText("File delete");
                            }
                            tof.printLineText("Loading list of save :");
                            this.iofs.listAllSave();
                            saveList = iofs.getSaveFile();//get all name
                            if (saveList.isEmpty()) {
                                tof.printLineText("No save find");
                                tof.printLineText("Generating a new game...");
                                this.State = GameState.New;
                            }

                        } else {
                            boolean ok = this.iofs.loadSave(this.iofs.getFile(FilePos));
                            if (ok) {
                                this.State = GameState.Area;
                            } else {
                                this.State = GameState.New;
                            }
                        }
                    }

                    break;
                case Win:
                    tof.printFormText("You... You did it...\nYou beat the final boss\nGood job !!!\n");
                    tof.printLineText("Let see your score :");

                    tof.printLineText("Money :" + myPlayer.getCredit());
                    tof.printLineText("Damage :" + myPlayer.getAllDamage());
                    tof.printLineText("RepairKit use :" + myPlayer.getNumberRepairKit());
                    tof.printLineText("Place discover :" + myPlayer.getNumberPlaceDiscover());

                    int score = 1000;//
                    score += myPlayer.getCredit() * 99;
                    score -= myPlayer.getAllDamage() * 15;
                    score -= myPlayer.getNumberRepairKit() * 12;
                    score -= myPlayer.getNumberPlaceDiscover() * 123;

                    ArrayList<String> listAchievement = new ArrayList<>();
                    tof.printLineText("Total score :" + score);
                    if (score < 1000) {
                        tof.printLineText("At least you beat the game");
                    } else {
                        tof.printLineText("Amazing highScore");
                        listAchievement.add("#Super score");

                    }
                    listAchievement.add("#Beat the game");
                    if (myPlayer.getNumberRepairKit() == 0) {
                        tof.printLineText("Achievement #How do you first aid  --> No RepairKit use");
                        listAchievement.add("#How do you first aid");
                    }
                    if (myPlayer.getNumberRepairKit() > 10) {
                        tof.printLineText("Achievement #Have you seen my -Winnie the Pooh- bandage  --> More than 10 RepairKit use");
                        listAchievement.add("#Have you seen my -Winnie the Pooh- bandage");
                    }

                    if (myPlayer.getAllDamage() == 0) {
                        tof.printLineText("Achievement #They are StormTroopers,don't know how to aim  --> No damage get");
                        listAchievement.add("#They are StormTroopers,don't know how to aim");
                    }
                    if (myPlayer.getAllDamage() > 100) {
                        tof.printLineText("Achievement #I'm invicible  --> More than 100 damage get");
                        listAchievement.add("#I'm invicible");
                    }

                    if (myPlayer.getNumberPlaceDiscover() < 5) {
                        tof.printLineText("Achievement #That was fast...  --> Less than 5 place visited");
                        listAchievement.add("#That was fast...");
                    } else if (myPlayer.getNumberPlaceDiscover() < 20) {
                        tof.printLineText("Achievement #Arond the world,Arond the world...  --> Less than 20 place visited");
                        listAchievement.add("#Arond the world,Arond the world... ");
                    } else {
                        tof.printLineText("Achievement #Tourist...  --> More than 20 place visited");
                        listAchievement.add("#Tourist...");
                    }

                    ///save
                    //read 
                    File file = new File("highScore.txt");
                    String st = "";
                    ArrayList<String> listScore = new ArrayList<>();
                    try {
                        BufferedReader br = new BufferedReader(new FileReader(file));

                        while ((st = br.readLine()) != null) {
                            listScore.add(st);
                        }
                    } catch (Exception e) {
                    }
                    //file
                    PrintWriter writer = new PrintWriter("highScore.txt", "UTF-8");
                    writer.println(myPlayer.getNAME() + ":");
                    writer.println(score);
                    for (String str : listAchievement) {
                        writer.println(str);
                    }

                    writer.println("---");

                    listScore.forEach((str) -> {
                        writer.println(str);
                    });

                    writer.close();

                    tof.printLineText("Do you want to quit or restart the game?");
                    tof.printLineText("(QUIT or RESTART)");
                    answer = scan.nextLine();

                    /*Verification */
                    while (!"QUIT".equalsIgnoreCase(answer) && !"RESTART".equalsIgnoreCase(answer)) {
                        tof.printLineText("Action not reconize");
                        answer = scan.nextLine();
                    }

                    if ("RESTART".equalsIgnoreCase(answer)) {
                        this.State = GameState.Start;
                    } else {
                        this.State = GameState.Quit;
                    }

                    break;

                case GameOver:
                    tof.printLineText("Your Ship is destroy ...");
                    tof.printLineText("GameOver");

                    tof.printLineText("Do you want to quit or restart the game?");
                    tof.printLineText("(QUIT or RESTART)");
                    answer = scan.nextLine();

                    /*Verification */
                    while (!"QUIT".equalsIgnoreCase(answer) && !"RESTART".equalsIgnoreCase(answer)) {
                        tof.printLineText("Action not reconize");
                        answer = scan.nextLine();
                    }

                    if ("RESTART".equalsIgnoreCase(answer)) {
                        this.State = GameState.Start;
                    } else {
                        this.State = GameState.Quit;
                    }

                    break;
                case Area:
                    tof.printLineMid();
                    //show area
                    if (this.myPlayer.getMyPlace().getID_Place() != numPreviousPlace) {
                        Thread.sleep(1000);
                        Place localP = myPlayer.getMyPlace();
                        tof.printLineText(localP.getNameLocation());
                        String[] cutName = localP.getNameLocation().split(" ");
                        tof.printFormText(tof.getForm(cutName[0]));
                        tof.printFormText(localP.getDescription());
                        tof.printLineMid();
                        numPreviousPlace = this.myPlayer.getMyPlace().getID_Place();
                    }
                    ///player desc
                    tof.printLineText(this.myPlayer.getNAME() + " : ");
                    tof.printLineText("LifePoint : " + this.myPlayer.getHp() + "/" + this.myPlayer.getMax_hp());
                    tof.printLineText("Shield : " + this.myPlayer.getSheild().getEnergy() + "/" + this.myPlayer.getSheild().getEnergyMax());
                    tof.printLineText("Fuel left : " + this.myPlayer.getFuelMeter());
                    tof.printLineText("Your Spaceship is level " + this.myPlayer.getRank());


                    if (myPlayer.getMyPlace().enemyNearby()) //enemi in the room
                    {
                        tof.printLineText("WARNING : Enemy are nearby");
                        ListEnemy = this.myPlayer.getMyPlace().getListOfSO();
                    }
                    
                    tof.printLineAction(listAction);

                    tof.printLineText("Select A command");
                    answer = scan.nextLine();

                    /*Verification */
                    String[] tabOfAction = new String[6];
                    tabOfAction = answer.split(" ");

                    while (!listAction.contains(tabOfAction[0].toUpperCase())) {
                        tof.printLineText("Action not reconize");
                        answer = scan.nextLine();//
                        tabOfAction = answer.split(" ");//re split
                    }

                    if ("MAP".equalsIgnoreCase(tabOfAction[0])) {
                        drawMap();//print map
                    } else if (!"SAVE".equalsIgnoreCase(tabOfAction[0]) && !"QUIT".equalsIgnoreCase(tabOfAction[0])&& !"RESET".equalsIgnoreCase(tabOfAction[0])) {
                        myPlayer.doAction(answer);
                    }

                    //get ending message
                    if (ListEnemy != null) //enemi in the room
                    {
                        
                        for (Map.Entry<String, SpacialObject> thisEmap : ListEnemy.entrySet()) {
                            
                            String _key = thisEmap.getKey();
                            SpacialObject _e = thisEmap.getValue();
                            
                            int luckForAttack = _e.getRank()*10;
                            if (randomInt(randomInt(100)) < luckForAttack  && !_e.getMapEquipedWeapons().isEmpty())// 0-80 < 1/8 --> 12.5%
                            {
                                tof.printLineText(_key + " attack you ...");
                                ((Enemy)_e).useWeapon(_e.getMapEquipedWeapons().get(1), myPlayer);///quand attaquer affiche
                            }
                            else
                            {
                                tof.printLineText(_key + " is near ...");
                            }
                            if (myPlayer.is_destroy() ) {
                                this.State = GameState.GameOver;
                                break;
                            }
                        }
                    }

                    if (myPlayer.is_destroy()|| myPlayer.isOutOfFuel()) {
                        this.State = GameState.GameOver;
                        break;
                    }
                    int num1 = this.ListPlace.get(this.ListPlace.size() - 1).get(0).getID_Place();
                    int num2 = this.myPlayer.getMyPlace().getID_Place();
                    if (!myPlayer.getMyPlace().enemyNearby() && (num1 == num2)) //no enemi and last room
                    {
                        this.State = GameState.Win;
                    }

                    break;

                case Quit:
                    
                    String lastChoice = answer;//reset or quit
                    tof.printLineText("Do you want to save ?");

                    tof.printLineText("(Yes or No)");
                    answer = scan.nextLine();

                    /*Verification */
                    while (!"YES".equalsIgnoreCase(answer) && !"NO".equalsIgnoreCase(answer)) {
                        tof.printLineText("Action not reconize");
                        answer = scan.nextLine();
                    }

                    if ("YES".equalsIgnoreCase(answer)) {
                        tof.printLineText("Name save");
                        String FileName = scan.nextLine();

                        while ("".equalsIgnoreCase(FileName)) {
                            tof.printLineText("unvalide");
                            FileName = scan.nextLine();
                        }
                        tof.printLineText("Saving");
                        iofs.newSave(FileName,this.myPlayer);
                    }
                    if(!"RESET".equalsIgnoreCase(lastChoice))
                    {
                        tof.printFormText("Thanx for playing\nBrought by\nKillian Chretien\nRomain Barbier\nThomas Cantonny\n");
                        tof.printLineText("Any resemblance to real and actual names is purely coincidental.");
                        tof.printLineText("no animals were mistreated during coding...");
                        tof.printLineText("Besides the programmers who leaked blood and tear to finish the project.");
                        tof.printLineText("Press enter to quit ...");
                        scan.nextLine();

                        this.State = GameState.End; //get out of while for finish main()
                    }
                    else
                    {
                        this.State = GameState.Start; //reset
                    }
                    break;
            }
            if (answer != null) {
                if (answer.equalsIgnoreCase("QUIT")|| answer.equalsIgnoreCase("RESET")) {
                    this.State = GameState.Quit; //get ending message
                } else if (answer.equalsIgnoreCase("SAVE")) {
                    tof.printLineText("Name save");
                    String FileName = scan.nextLine();

                    while ("".equalsIgnoreCase(FileName)) {
                        tof.printLineText("unvalide");
                        FileName = scan.nextLine();
                    }
                    tof.printLineText("Saving");
                    
                    
                    iofs.newSave(FileName,this.myPlayer);

                }//get ending message
            }
        } while (this.State != GameState.End);
    }

    //Simple fonction for an int to random 5 --> 0-4 (pour simplifier l'écriture dans le code)

    private int randomInt(int nb) {
        return (int) (Math.random() * nb);
    }

    public int randomInt_range(int min, int max) {
        int rnd = 0;
        if (min < 0) {
            rnd = min + (int) (Math.random() * max - min);
        } else {
            rnd = randomInt(max);
        }
        return rnd;
    }

    public Action getAction(String strAction) {
        for (Action var : Action.values()) {
            if (strAction.equalsIgnoreCase(var.name())) {
                return var;
            }
        }
        return null;
    }
//get a form from the name planet --> O

    public String getFormOfPlace(String name) {
        int pos = 0;

        if (myPlayer != null && myPlayer.getMyPlace().getNameLocation().equals(name))//posisiton player
        {
            return "  P  ";
        }
        for (String firstName : FNAME) {//match we final name
            if (name.startsWith(firstName)) {
                return this.FNAMEFORM[pos];
            }
            pos++;
        }
        if (name.startsWith("Final"))//Final place
        {
            return "  B  ";
        }
        if (name.startsWith("Home"))//first place
        {
            return "  S  ";
        }
        return "  N  ";

    }


    //Draw the map
    private void drawMap() {
        String lineNumber = "";
        for (int i = 0; i < ListPlace.size(); i++) {
            lineNumber += "  " + i + "  ";
        }
        tof.printLineMid();
        tof.printLineText("S-->Start Place/B-->Boss/P-->Player");
        int pos = 0;
        String lineText = "";
        for (String firstName : FNAME) {
            lineText += FNAMEFORM[pos].replace(" ", "") + "-->" + firstName + "/";//form " O ".replace --> "O"
            pos++;
        }
        tof.printLineText(lineText);
        tof.printLineMid();
        tof.printFormText(lineNumber + "\n" + this.mg.getDrawMap(this.myPlayer));///\n\nStrange appears
        tof.printLineMid();
    }

    //Check for an input string is form of int
    public boolean isInt(String val) {
        try {
            // checking valid integer using parseInt() method 
            Integer.parseInt(val);
            //System.out.println(val + " is a valid integer number"); 
            return true;
        } catch (NumberFormatException e) {
            //System.out.println(val + " is not a valid integer number"); 
            return false;
        }
    }

}
