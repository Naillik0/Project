/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ToInfinityAndBeyond.GameControlPackage;

import ToInfinityAndBeyond.ZoneIneractionsPackage.Material;
import ToInfinityAndBeyond.ZoneIneractionsPackage.BarrelOfFuel;
import ToInfinityAndBeyond.ZoneIneractionsPackage.Exit;
import ToInfinityAndBeyond.ZoneIneractionsPackage.RepairKit;
import ToInfinityAndBeyond.ZoneIneractionsPackage.Items;
import ToInfinityAndBeyond.ZoneIneractionsPackage.Place;
import ToInfinityAndBeyond.ZoneIneractionsPackage.Ammo;
import ToInfinityAndBeyond.ZoneIneractionsPackage.Credit;
import ToInfinityAndBeyond.SpacialPackage.*;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Naillik
 */
public class MapGeneration {

    private ArrayList<ArrayList<Place>> ListPlace = new ArrayList<>();

    private final String[] FNAME = {"Planet", "Zone", "Asteroid", "Satellite", "Moon"};
    private final String[] FNAMEFORM = {"  O  ", "  *  ", "  °  ", " -o- ", "  C  "};
    private final String[] nameMaterials = {"Diamond", "Rubis", "Saphir", "Amenysth", "Crystal"};
    private final int[] priceMaterials = {100, 80, 65, 49, 20};
    private final String[] nameEnemy = {"Meteor", "EnemyShooter", "AlienShip", "EnemyWalker", "EnemyShip"};

    private int sizeOfMap = 0;

    MapGeneration(String sizeOption) throws CloneNotSupportedException {
        int nbOfName = 5;

        String[] Sname = {"Alpha", "Beta", "Teta", "Omega", "Zeta"};
        String[] Lname = {"Naillik", "Quamicaz", "Niamor", "LaPalma", "Nimesis"};

        String[] Sdescription = {
            "This FNAME is a typical place for tourists.\n"
            + "It's not hard to find what you're looking for.\n",
            "This FNAME is the same everywhere, so easy to lose ...\n",
            "It feels good here on a FNAME, but it is not necessarily the place for a family.\n",
            "With this FNAME we have access to Yensid channel, a good return to childhood ...\n",
            "This FNAME is beautiful, but does not have the taste of cheese.\n"};
        String[] Ldescription = {
            "Its danger level is 0.\n"
            + "Pacific and friendly.\n",
            "Its danger level is 2.\n"
            + "Pacific but watch out for the thief\n",
            "Its danger level is 4.\n"
            + "Nice place but some fight in the bars ....\n",
            "Its danger level is 6.\n"
            + "Pirate, killer, comet, robot, clown ...\n "
            + "A lot of non-recommendable person for babysitting ...\n",
            "Its danger level is 8.\n"
            + "On a scale of richter, it seems dangerous for a scout camp.\n",};

        //set a size
        int size_step = 1;//longeur
        if ("MEDIUM".equalsIgnoreCase(sizeOption)) {
            size_step = 2;
        } else if ("BIG".equalsIgnoreCase(sizeOption)) {
            size_step = 3;
        }

        int numPlanet = 0;
        ArrayList<Place> listStepPlace = new ArrayList<>();

        //
        Place homeP = new Place("Home Planet", "Home sweet home\n" + Sdescription[0].replace("FNAME", "home") + Ldescription[0], numPlanet);
        listStepPlace.add(homeP);
        ListPlace.add((ArrayList<Place>) listStepPlace.clone());//clone car généré dans une liste temporaire

        listStepPlace.clear();
        int fnRnd = 1; //nb planet from step before
        int lastNbP = fnRnd;
        for (int step = 1; step <= size_step * 2; step++) {
            for (int step_hight = 1; step_hight <= size_step; step_hight++) {
                if (step < size_step * 1.5) {
                    fnRnd = randomInt_range(1, 3) + fnRnd;//more planet
                    if (fnRnd > lastNbP + 2) {
                        fnRnd = lastNbP + 2;
                    }
                    lastNbP = fnRnd;
                } else {
                    fnRnd = (int) Math.ceil(fnRnd * 8 / 10);//less after middle
                }                //if(fnRnd > (size_step*2)+1) fnRnd = (size_step*2)+1; //depasse pas la limite 2*2 = 4 planet par step

                for (int rnd = 0; rnd <= fnRnd; rnd++) {
                    numPlanet++;
                    int rFn = randomInt(nbOfName);
                    int rSn = randomInt(nbOfName);
                    Place p = new Place(FNAME[rFn] + " " + Sname[rSn] + " " + Lname[randomInt(nbOfName)],
                            Sdescription[rFn].replace("FNAME", FNAME[rFn]) + Ldescription[rSn], numPlanet);

                    addItemsInPlace(p);

                    listStepPlace.add(p);
                }
                ListPlace.add((ArrayList<Place>) listStepPlace.clone());
                listStepPlace.clear();
            }
        }
        numPlanet++;

        listStepPlace.clear();
        Place bossP = new Place("Final Boss", "This is it...\nThe final boss...\n" + Sdescription[4].replace("FNAME", "place") + Ldescription[4], numPlanet);
        listStepPlace.add(bossP);

        ListPlace.add((ArrayList<Place>) listStepPlace.clone());//clone car généré dans une liste temporaire

        //Reverse
        //Collections.reverse(ListPlace);
        ListPlace.get(1).forEach((p) -> {
            ListPlace.get(0).get(0).addExit(new Exit(randomInt(2) + 1, p));
        });
        this.sizeOfMap = getMaxPlanetOfList();//get max for draw
        //generate exit

        //rnd 1-3
        Place[][] tabListLignePlace = new Place[sizeOfMap][ListPlace.size()];

        for (int listnum = 0; listnum < ListPlace.size() - 1; listnum++) {

            ArrayList<Place> list = ListPlace.get(listnum);

            for (int numero = 0; numero < list.size(); numero++) {
                //Place pl = new Place("","",-1);
                //tabListLignePlace[numero].add(pl);
                tabListLignePlace[numero][listnum] = list.get(numero);
            }

            for (int lastnumero = list.size(); lastnumero < sizeOfMap; lastnumero++) {
                tabListLignePlace[lastnumero][listnum] = null;//
            }

        }

        for (int posCase = 0; posCase < sizeOfMap; posCase++)//jusqua 1
        {
            for (int slist = 1; slist < tabListLignePlace[posCase].length - 1; slist++)//p+1 a p-1
            {
                if (tabListLignePlace[posCase][slist] != null) {
                    Place a = tabListLignePlace[posCase][slist];
                    for (int i = -2; i <= 2; i += 2) {
                        if ((sizeOfMap) > posCase + i && posCase + i >= 0) {

                            if (tabListLignePlace[posCase + i][slist + 1] != null) {
                                Place b = tabListLignePlace[posCase + i][slist + 1];
                                a.addExit(new Exit(randomInt(2) + 1, b));
                            }
                        } else if ((sizeOfMap) > posCase + i && posCase + i >= -2) {
                            if (tabListLignePlace[0][slist + 1] != null) {
                                Place b = tabListLignePlace[0][slist + 1];
                                a.addExit(new Exit(randomInt(2) + 1, b));
                            }
                        }
                    }
                }
            }
        }

        //for home
        for (Place pNextHome : ListPlace.get(1)) {

            homeP.addExit(new Exit(randomInt(2) + 1, pNextHome));
        }
        for (Place pBeforeBoss : ListPlace.get(ListPlace.size() - 2)) {

            pBeforeBoss.addExit(new Exit(randomInt(2) + 1, bossP));
        }
        addEnemysInMap();
    }
    //Simple fonction for an int to random 5 --> 0-4 (pour simplifier l'écriture dans le code)

    private int randomInt(int nb) {
        return (int) (Math.random() * nb);
    }

    private int randomInt_range(int min, int max) {
        int rnd = 0;
        if (min < 0) {
            rnd = min + (int) (Math.random() * max - min);
        } else {
            rnd = randomInt(max);
        }
        return rnd;
    }

    public Action getAction(String strAction) {
        for (Action var : Action.values()) {
            if (strAction.equalsIgnoreCase(var.name())) {
                return var;
            }
        }
        return null;
    }
//get a form from the name planet --> O

    public String getFormOfPlace(String name, Player myPlayer) {
        int pos = 0;

        if (myPlayer != null && myPlayer.getMyPlace().getNameLocation().equals(name))//posisiton player
        {
            return "  P  ";
        }
        for (String firstName : FNAME) {//match we final name
            if (name.startsWith(firstName)) {
                return this.FNAMEFORM[pos];
            }
            pos++;
        }
        if (name.startsWith("Final"))//Final place
        {
            return "  B  ";
        }
        if (name.startsWith("Home"))//first place
        {
            return "  S  ";
        }
        return "  N  ";

    }

    //when load or new map we retore the size to make it printable
    private int getMaxPlanetOfList() {
        int max = 0;
        for (ArrayList list : ListPlace) {
            if (max < list.size()) {
                max = list.size();  //biggest size of a list of planet
            }
        }
        return max;
    }

    //Prepare the pseudo form of the map to make it printable in string
    public String getDrawMap(Player myPlayer) {
        String[] tabMapOfString = new String[sizeOfMap];//tableau listant par ligne

        for (int num = 0; num < ListPlace.size(); num++) {

            ArrayList<Place> list = ListPlace.get(num);

            for (int numPlanet = 0; numPlanet < list.size(); numPlanet++) {
                if (tabMapOfString[numPlanet] == null) {
                    tabMapOfString[numPlanet] = "";//init of case
                }
                tabMapOfString[numPlanet] += (getFormOfPlace(list.get(numPlanet).getNameLocation(), myPlayer));
                if (num > 9) {
                    tabMapOfString[numPlanet] += " ";
                }
            }

            for (int lastCase = list.size(); lastCase < sizeOfMap; lastCase++) {
                if (tabMapOfString[lastCase] == null) {
                    tabMapOfString[lastCase] = "";//init of case
                }
                tabMapOfString[lastCase] += "     ";
                if (num > 9) {
                    tabMapOfString[lastCase] += " ";
                }
            }

        }

        String mapString = "";
        for (int posCase = sizeOfMap - 1; posCase > 0; posCase--)//jusqua 1
        {
            if ((posCase % 2) != 0)//impair
            {
                mapString += posCase + tabMapOfString[posCase] + "\n";
            }
        }

        for (int posCase = 0; posCase < sizeOfMap; posCase++)//jusquau max -1
        {
            if (posCase % 2 == 0)//pair
            {
                mapString += posCase + tabMapOfString[posCase] + "\n";
            }
        }
        return mapString;

    }

    //Check for an input string is form of int
    private boolean isInt(String val) {
        try {
            // checking valid integer using parseInt() method 
            Integer.parseInt(val);
            //System.out.println(val + " is a valid integer number"); 
            return true;
        } catch (NumberFormatException e) {
            //System.out.println(val + " is not a valid integer number"); 
            return false;
        }
    }

    private void addItemsInPlace(Place p) throws CloneNotSupportedException {

        HashMap<String, Items> listItemsToAdd = new HashMap<>();
        if (randomInt(100) < 25)//si 0 ----> 25% RepairKit
        {
            listItemsToAdd.put("RepairKit".toUpperCase(), new RepairKit(2));
        }
        if (randomInt(100) < 60)//si 0 ----> 1/2 Barrel
        {
            listItemsToAdd.put("Barreloffuel".toUpperCase(), new BarrelOfFuel(randomInt_range(1,5)));
        }
        if (randomInt(100) < 25)//si 0 ----> 1/2 ammo pack 2 --> 4
        {
            listItemsToAdd.put("Ammo".toUpperCase(), new Ammo(randomInt(2) + 2));
        }
        if (randomInt(100) < 60)//si 0 ----> 20 -100 max
        {
            listItemsToAdd.put("Credit".toUpperCase(), new Credit(randomInt(80) + 20));
        }

        if (randomInt(100) < 30)//si 0 ----> material
        {
            int rnd_mat = randomInt(4);
            listItemsToAdd.put(nameMaterials[rnd_mat].toUpperCase(), new Material(nameMaterials[rnd_mat], priceMaterials[rnd_mat], randomInt(10)));
        }
        p.setItems(listItemsToAdd);
    }

    private HashMap<String, Items> getItemsforEnemyRank(int enemyRank) {
        HashMap<String, Items> listItemsToAdd = new HashMap<>();

        if (enemyRank != 0) {// isn't meteor
            if (randomInt(100) < 25)//si 0 ----> 25% RepairKit
            {
                listItemsToAdd.put("REPAIRKIT", new RepairKit(1 * enemyRank));
            }
            if (randomInt(100) < 50)//si 0 ----> 1/2 Barrel
            {
                listItemsToAdd.put("BARRELOFFUEL", new BarrelOfFuel(1 * enemyRank));
            }
            if (randomInt(100) < 25)//si 0 ----> 1/2 ammo pack 2 --> 4
            {
                listItemsToAdd.put("AMMO", new Ammo(randomInt(2 * enemyRank) + 2));
            }
            if (randomInt(100) < 60)//si 0 ----> 20 -100 max
            {
                listItemsToAdd.put("CREDIT", new Credit(randomInt(80 * enemyRank) + 20));
            }

            if (randomInt(100) < 30)//si 0 ----> material
            {
                for (int mat = 0; mat < enemyRank; mat++) {
                    int rnd_nb = randomInt(30)+1;
                    int rnd_mat = randomInt(4);
                    listItemsToAdd.put(nameMaterials[rnd_mat], new Material(nameMaterials[rnd_mat], priceMaterials[rnd_mat], rnd_nb));
                }
            }
        } else {
            for (int mat = 0; mat < 5; mat++) {
                int rnd_nb = randomInt(30)+1;
                int rnd_mat = randomInt(4);
                listItemsToAdd.put(nameMaterials[rnd_mat].toUpperCase(), new Material(nameMaterials[rnd_mat], priceMaterials[rnd_mat], rnd_nb));
            }
        }
        return listItemsToAdd;
    }

    ArrayList<ArrayList<Place>> getMap() {
        return ListPlace;
    }

    private void addEnemysInMap() {
                //add enemy
        int numPmax = ListPlace.get(ListPlace.size()-1).get(ListPlace.get(ListPlace.size()-1).size()-1).getID_Place();
        for (ArrayList<Place> listpEnemy : ListPlace) {
            for (Place pEnemy : listpEnemy) {
                Storage tempS = new Storage(100);
                HashMap<Integer,Weapons> tabPreMakeW = new HashMap<>();
                
                Enemy _e = null;
                //Enemy(String name, int hp, int rank, HashMap<Integer, Weapons> tabWeapons, Storage inventory, Shield shield, int _fuelMeter)
                if (pEnemy.getID_Place() > numPmax * 1 / 4 && randomInt(100) < 80) //weak
                {
                    tempS.refresh(getItemsforEnemyRank(0));
                    _e = new Enemy(nameEnemy[0], 5, 0, null, tempS, null, 0);
                    pEnemy.addEnemy(_e);
                    _e.setMyPlace(pEnemy);

                    
                }
                if (pEnemy.getID_Place() > numPmax * 2 / 4 && randomInt(100) < 60) {
                    if (pEnemy.getNameLocation().contains("Planet"))//
                    {
                        tempS.refresh(getItemsforEnemyRank(1));

                        tabPreMakeW.put(1, new Blaster());
                        
                        _e = new Enemy(nameEnemy[1], 8, 1, tabPreMakeW, tempS, new Shield(false, 2), 0);
                        
                        pEnemy.addEnemy(_e);
                        _e.setMyPlace(pEnemy);

                    } else {
                        tempS.refresh(getItemsforEnemyRank(2));
                        
                        tabPreMakeW.put(1, new Blaster());
                        
                        tempS.addItem(new Ammo(50));
                        
                        _e = new Enemy(nameEnemy[2], 12, 2, tabPreMakeW, tempS, new Shield(true, 2), 0);
                        pEnemy.addEnemy(_e);
                        _e.setMyPlace(pEnemy);

                    }
                }
                if (pEnemy.getID_Place() > numPmax * 3 / 4 && randomInt(100) < 50) //strong
                {
                    if (pEnemy.getNameLocation().contains("Planet")) {
                        tempS.refresh(getItemsforEnemyRank(3));
                        
                        tabPreMakeW.put(1, new IEM());
                        
                        _e = new Enemy(nameEnemy[3], 25, 3, tabPreMakeW, tempS, new Shield(false, 10), 0);
                        pEnemy.addEnemy(_e);
                        _e.setMyPlace(pEnemy);

                    } else {
                        tempS.refresh(getItemsforEnemyRank(4));
                        
                        tabPreMakeW.put(1, new Lazer());
                        _e = new Enemy(nameEnemy[4], 15, 4, tabPreMakeW, tempS, new Shield(false, 20), 0);
                        pEnemy.addEnemy(_e);
                        _e.setMyPlace(pEnemy);

                    }
                }
                
                if(_e!=null)
                {
                    //System.out.println(_e.getNAME()); //generation....
                
                }
            }
        }
    }

}
