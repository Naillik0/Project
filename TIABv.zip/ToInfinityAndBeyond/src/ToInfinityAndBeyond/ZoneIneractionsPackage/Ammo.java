package ToInfinityAndBeyond.ZoneIneractionsPackage;

import ToInfinityAndBeyond.SpacialPackage.*;

public class Ammo extends Items {

    private final static int PRICE = 1;
    private final static String NAME = "Ammo";
    private static final boolean isUsable = false;
    public Ammo(int _quantity) {
        super(NAME, _quantity, PRICE,isUsable);
    }

    @Override
    public void useItemOn(SpacialObject thisPlayer) {
        System.out.println("this object is unusable");
    }

}