package ToInfinityAndBeyond.ZoneIneractionsPackage;

import ToInfinityAndBeyond.SpacialPackage.*;

public class RepairKit extends Items  {

    private static final int PRICE = 10;
    private final static String NAME = "ToolKit";
    private final static int HEAL = 5;
    private static final boolean isUsable = true;
        
    public RepairKit(int _quantity) {
        super(NAME,_quantity,PRICE,isUsable);
    }

    
    @Override
    public void useItemOn(SpacialObject thisPlayer) {
         thisPlayer.addLife(HEAL);
    }
    

}