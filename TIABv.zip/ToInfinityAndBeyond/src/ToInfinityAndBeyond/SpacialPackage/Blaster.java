package ToInfinityAndBeyond.SpacialPackage;

public class Blaster extends Weapons {

    public Blaster() {
        super("Blaster", 2, 1, false, 1, 50);
    }
    
    @Override
    public void useItemOn(SpacialObject target) {
        target.getHit(this.getDamage(),1,1); // x1 sur la vie et bouclier
    }

    @Override
    public boolean haveAmmo(SpacialObject theShooter) {
        return true;
    }

}