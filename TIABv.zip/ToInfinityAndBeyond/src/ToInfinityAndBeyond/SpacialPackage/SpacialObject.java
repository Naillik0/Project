package ToInfinityAndBeyond.SpacialPackage;

import ToInfinityAndBeyond.ZoneIneractionsPackage.Place;
import java.io.Serializable;
import java.util.HashMap;

public abstract class SpacialObject implements Serializable {

    //CONSTANT
        private final String NAME;
        
    //VARIABLE    
        private int lifePointMax;
        private int LifePoint;
	private int Rank;
        transient Shield myShield;
        private transient Storage myStorage;
        private transient  Place myPlace;
        private int fuelMeter;
    //HASHMAP    
	private transient HashMap<Integer,Weapons> MapEquipedWeapons; 

    //BUILDER
	public SpacialObject(String name, int hp, int rank, HashMap<Integer,Weapons> tabWeapons, Storage inventory, Shield shield,int _fuelMeter) {
		this.NAME=name;
                this.lifePointMax=hp;
                this.LifePoint=hp;
                this.Rank=rank;
                this.myShield=shield;
                this.myStorage=inventory;
                this.MapEquipedWeapons=tabWeapons;
                this.fuelMeter=_fuelMeter;
	}
        
    //METHOD
        public String getNAME(){
            return this.NAME;
        }
        
        public int getMax_hp() {
            return lifePointMax;
        }

        public void setMax_hp(int max_hp) {
            this.lifePointMax = max_hp;
        }
        
        public void getHit(int damage,int damageShield,int damageOnHp){
            
                if(this.myShield==null || damageShield == -1){
                    
                    this.LifePoint-=damage * damageOnHp;
                }else{
                    
                    int rest=this.myShield.DecreaseEnergy(damage*damageShield);
                    rest = rest*(damage*damageOnHp)/(damage*damageShield);
                    this.LifePoint-=rest;
                }
            
        }

        public void setMyPlace(Place myPlace) {
            this.myPlace = myPlace;
        }

        
        public void addLife(int HEAL) {
            this.LifePoint+=HEAL;
        }

        public int getRank() {
            return this.Rank;
        }

        public void setRank(int rank) {
            this.Rank = rank;
        }

        public HashMap<Integer, Weapons> getMapEquipedWeapons() {
            return MapEquipedWeapons;
        }


        public boolean is_destroy() {
            return this.LifePoint<=0;
        }

        public boolean haveWeaponEquip() {
            return this.MapEquipedWeapons != null;
        }

        public void addFuel(int NBFUEL) {
            this.fuelMeter+=NBFUEL;
        }
        
        public void delFuel(int value) {
            this.fuelMeter -= value;
        }

        public int getFuelMeter() {
            return fuelMeter;
        }

        public Storage getMyStorage() {
            return myStorage;
        }

        public Place getMyPlace() {
            return myPlace;
        }

    public int getHp() {
        return this.LifePoint;
    }

    public Shield getSheild() {
        return this.myShield;
    }
        
        

}