package ToInfinityAndBeyond.ZoneIteractionsPackage;

import ToInfinityAndBeyond.SpacialPackage.*;

public class BarrelOfFuel extends Items {
    
    private static final int PRICE = 10;
    private final static String NAME = "BarelOfFuel";
    private final static int NBFUEL = 5;

    public BarrelOfFuel(int _quantity) {
        super(NAME, _quantity,PRICE);
    }

    @Override
    public void useItemOn(Player thisPlayer) {
        thisPlayer.addFuel(NBFUEL);
    }

}