package ToInfinityAndBeyond.ZoneIteractionsPackage;

import ToInfinityAndBeyond.SpacialPackage.*;

public abstract class Items {
        
//CONSTANT
    private final String NAME;
    private final int PRICE;
//VARIABLE
    private int Quantity;
      
        
//BUILDER        
    public Items(String name, int _quantity, int price) {
        this.NAME = name;
        this.Quantity = _quantity;
        this.PRICE = price;
    }

//METHOD
    public String getName() {
	return NAME;
    }

    public int getPrice() {
    	return PRICE;
    }

    public int getQuantity() {
	return Quantity;
    }

	
    public void addQuatity(int _quantity) {
        this.Quantity += _quantity;
    }

	
    public void delQuantity(int _quantity) {
        if(this.Quantity>0){
            this.Quantity -= _quantity;
        }
    }
        
    public abstract void useItemOn(Player thisPlayer);
        
}