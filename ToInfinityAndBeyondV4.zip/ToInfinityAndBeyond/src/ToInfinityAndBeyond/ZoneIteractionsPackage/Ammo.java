package ToInfinityAndBeyond.ZoneIteractionsPackage;

import ToInfinityAndBeyond.SpacialPackage.*;

public class Ammo extends Items {

	private final static int PRICE = 1;
    private final static String NAME = "Ammo";

    public Ammo(int _quantity) {
        super(NAME, _quantity, PRICE);
    }

    @Override
    public void useItemOn(Player thisPlayer) {
        System.out.println("this object is unusable");
    }

}