package ToInfinityAndBeyond.ZoneIteractionsPackage;

import ToInfinityAndBeyond.SpacialPackage.*;

public class Credit extends Items {

	private final static int PRICE = 1;
    private final static String NAME = "Credit";
    
    
    public Credit(int _quantity) {
        super(NAME, _quantity, PRICE);
    }
    
    @Override
    public void useItemOn(SpacialObject thisPlayer) {
            System.out.println("this object is unusable");
    }

}