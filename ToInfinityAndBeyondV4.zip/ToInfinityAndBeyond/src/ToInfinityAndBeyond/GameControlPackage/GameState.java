package ToInfinityAndBeyond.GameControlPackage;

public enum GameState {
	Start,
	Selection,
	Area,
	Shop,
	New,
	Win,
	GameOver,
	Quit,
	End
}