package ToInfinityAndBeyond.SpacialPackage;

import ToInfinityAndBeyond.ZoneIteractionsPackage.*;

public abstract class Weapons extends Items {

	private final int DAMAGE;
	private int Rank;
	private boolean useAmmo;

	
	public Weapons(String name, int damageDefault, int rank, boolean useAmm, int quant, int price) {
		// TODO - implement Weapons.Weapons
		throw new UnsupportedOperationException();
	}

	public boolean canShoot() {
		// TODO - implement Weapons.canShoot
		throw new UnsupportedOperationException();
	}

	public void upRank() {
		// TODO - implement Weapons.upRank
		throw new UnsupportedOperationException();
	}

	public boolean haveAmmo() {
		// TODO - implement Weapons.haveAmmo
		throw new UnsupportedOperationException();
	}

}