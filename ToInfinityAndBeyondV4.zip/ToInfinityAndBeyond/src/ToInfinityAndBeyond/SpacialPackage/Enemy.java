package ToInfinityAndBeyond.SpacialPackage;

import ToInfinityAndBeyond.ZoneIteractionsPackage.Items;
import ToInfinityAndBeyond.ZoneIteractionsPackage.Place;
import java.util.HashMap;

public class Enemy extends SpacialObject implements Shoot {

    public Enemy(String name, int hp, int rank, HashMap<Integer, Weapons> tabWeapons, Storage inventory, Shield shield, int _fuelMeter) {
        super(name, hp, rank, tabWeapons, inventory, shield, _fuelMeter);
    }

    public void loseItems() {
        Place pl=this.getMyPlace();
        HashMap<String,Items>enemyItems=this.getMyStorage().getListItems();
        enemyItems.entrySet().stream().map((entry) -> entry.getValue()).forEachOrdered((value) -> {
            pl.addItem(value);
        });
    }

	
    @Override
    public void useWeapon(Weapons thisWeapon, SpacialObject target) {
	if(thisWeapon.haveAmmo(this)){
            thisWeapon.useItemOn(target);
        }
    }

}