package ToInfinityAndBeyond.SpacialPackage;

import ToInfinityAndBeyond.GameControlPackage.*;
import ToInfinityAndBeyond.ZoneIteractionsPackage.*;

public class Player extends SpacialObject {

	private int damageTaken;
	private int repairKitUsed;
	private int placeDiscover;
	private TextOutputForm tof;
	private int fuelMeter = 10;

	public void upRank() {
		// TODO - implement Player.upRank
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param this_item
	 */
	public void UseThisItems(Items this_item) {
		// TODO - implement Player.UseThisItems
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisItem
	 */
	public boolean haveThisItem(Items thisItem) {
		// TODO - implement Player.haveThisItem
		throw new UnsupportedOperationException();
	}

	public String getInventory() {
		// TODO - implement Player.getInventory
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisAction
	 */
	public void doAction(Action thisAction) {
		// TODO - implement Player.doAction
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisWeapon
	 * @param position
	 */
	public void equipWeapon(Weapons thisWeapon, int position) {
		// TODO - implement Player.equipWeapon
		throw new UnsupportedOperationException();
	}

	public void unequipWeapons() {
		// TODO - implement Player.unequipWeapons
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param value
	 */
	public void addLife(int value) {
		// TODO - implement Player.addLife
		throw new UnsupportedOperationException();
	}

	public Weapons selectWeapon() {
		// TODO - implement Player.selectWeapon
		throw new UnsupportedOperationException();
	}

	public void getCredit() {
		// TODO - implement Player.getCredit
		throw new UnsupportedOperationException();
	}

	public void getAllDamage() {
		// TODO - implement Player.getAllDamage
		throw new UnsupportedOperationException();
	}

	public void getNumberRepairKit() {
		// TODO - implement Player.getNumberRepairKit
		throw new UnsupportedOperationException();
	}

	public void getNumberPlaceDiscover() {
		// TODO - implement Player.getNumberPlaceDiscover
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisWeapon
	 * @param enemy
	 */
	public void useWeapon(Weapons thisWeapon, SpacialObject enemy) {
		// TODO - implement Player.useWeapon
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param value
	 */
	public void addFuel(int value) {
		// TODO - implement Player.addFuel
		throw new UnsupportedOperationException();
	}

	public boolean isOutOfFuel() {
		// TODO - implement Player.isOutOfFuel
		throw new UnsupportedOperationException();
	}

}