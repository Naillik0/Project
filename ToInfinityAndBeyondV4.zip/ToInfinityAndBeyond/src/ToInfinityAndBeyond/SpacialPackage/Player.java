package ToInfinityAndBeyond.SpacialPackage;

import ToInfinityAndBeyond.GameControlPackage.*;
import ToInfinityAndBeyond.ZoneIteractionsPackage.*;
import java.util.HashMap;

public class Player extends SpacialObject implements Shoot {

	private int damageTaken;
	private int repairKitUsed;
	private int placeDiscover;
	private TextOutputForm tof;
	private int fuelMeter = 10;

        public Player(String name, int hp, int rank, HashMap<Integer, Weapons> tabWeapons, Storage inventory, Shield shield, int _fuelMeter,TextOutputForm _tof) {
            super(name, hp, rank, tabWeapons, inventory, shield, _fuelMeter);
            this.tof=_tof;
        }

	public void upRank() {
            if(this.getRank() < 2){
                HashMap<String,Items> Liste = this.getListItems();
                Items money = Liste.get("money");
                if(money.getQuantity() < priceUpgrade){
                    afficheText("Not enought money to upgrage your Spaceship");
                }
                else{
                    afficheText("Your Spaceship is level 2");
                    this.setRank(2); 
                    this.setMax_hp(40);
                    money.setQuantity(money.getQuantity()-priceUpgrade);
                }
            }
            else{
                afficheText("Your SpaceShip is already lvl max !"); //interface
            }
	}

	public void UseThisItems(Items this_item) {
            if(this.)){
                this_item.useItemOn(this);
                i.addQuantity(-1);
                liste.replace(name, i);
                inventory.refresh(liste);
                this.inventory = this.getInventory();
            }
            else
                afficheText("A weapon can only be <equipWeapon> or <unequipWeapon>. ");
        
        
	}

	
	public boolean haveThisItem(Items thisItem) {
            HashMap<String,Items> liste = this.getMyStorage().getListItems();
            return liste.containsValue(thisItem);
	}

	public String getInventory() {
		// TODO - implement Player.getInventory
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisAction
	 */
	public void doAction(Action thisAction) {
		// TODO - implement Player.doAction
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisWeapon
	 * @param position
	 */
	public void equipWeapon(Weapons thisWeapon, int position) {
		// TODO - implement Player.equipWeapon
		throw new UnsupportedOperationException();
	}

	public void unequipWeapons() {
		// TODO - implement Player.unequipWeapons
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param value
	 */
	public void addLife(int value) {
		// TODO - implement Player.addLife
		throw new UnsupportedOperationException();
	}

	public Weapons selectWeapon() {
		// TODO - implement Player.selectWeapon
		throw new UnsupportedOperationException();
	}

	public void getCredit() {
		// TODO - implement Player.getCredit
		throw new UnsupportedOperationException();
	}

	public void getAllDamage() {
		// TODO - implement Player.getAllDamage
		throw new UnsupportedOperationException();
	}

	public void getNumberRepairKit() {
		// TODO - implement Player.getNumberRepairKit
		throw new UnsupportedOperationException();
	}

	public void getNumberPlaceDiscover() {
		// TODO - implement Player.getNumberPlaceDiscover
		throw new UnsupportedOperationException();
	}

	
        @Override
	public void useWeapon(Weapons thisWeapon, SpacialObject enemy) {
		// TODO - implement Player.useWeapon
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param value
	 */
	public void addFuel(int value) {
		// TODO - implement Player.addFuel
		throw new UnsupportedOperationException();
	}

	public boolean isOutOfFuel() {
		// TODO - implement Player.isOutOfFuel
		throw new UnsupportedOperationException();
	}

}