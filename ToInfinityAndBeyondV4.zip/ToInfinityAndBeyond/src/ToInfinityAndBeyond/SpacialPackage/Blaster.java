package ToInfinityAndBeyond.SpacialPackage;

import ToInfinityAndBeyond.ZoneIteractionsPackage.Items;
import java.util.HashMap;

public class Blaster extends Weapons {

    public Blaster(String name, int damageDefault, int rank, boolean useAmm, int quant, int price) {
        super(name, damageDefault, rank, useAmm, quant, price);
    }
    
    @Override
    public void useItemOn(SpacialObject target) {
        target.getHit(this.getDamage());
    }

    @Override
    public boolean haveAmmo(SpacialObject theShooter) {
        HashMap<String,Items> lesItems= theShooter.getMyStorage().getListItems();
        return lesItems.containsKey("Ammo");
    }

}