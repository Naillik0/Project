package ToInfinityAndBeyond.SpacialPackage;

import ToInfinityAndBeyond.ZoneIteractionsPackage.*;
import java.util.HashMap;

public abstract class SpacialObject {

    //CONSTANT
        private final String NAME;
        
    //VARIABLE    
        private int lifePointMax;
        private int LifePoint;
	private int Rank;
        private Shield myShield;
        private Storage myStorage;
        private Place myPlace;
        private int fuelMeter;
    //HASHMAP    
	private HashMap<Integer,Weapons> MapEquipedWeapons; 

    //BUILDER
	public SpacialObject(String name, int hp, int rank, HashMap<Integer,Weapons> tabWeapons, Storage inventory, Shield shield,int _fuelMeter) {
		this.NAME=name;
                this.lifePointMax=hp;
                this.LifePoint=hp;
                this.Rank=rank;
                this.myShield=shield;
                this.myStorage=inventory;
                this.MapEquipedWeapons=tabWeapons;
                this.fuelMeter=_fuelMeter;
	}
        
    //METHOD
        public String getNAME(){
            return this.NAME;
        }
        
        public int getMax_hp() {
            return lifePointMax;
        }

        public void setMax_hp(int max_hp) {
            this.lifePointMax = max_hp;
        }
        
        public void getHit(int damage){
            if(this.myShield==null){
                this.LifePoint-=damage;
            }else{
                int rest=this.myShield.DecreaseEnergy(damage);
                this.LifePoint-=damage;
            }
            
        }

        public void addLife(int HEAL) {
            this.LifePoint+=HEAL;
        }

        public int getRank() {
            return this.Rank;
        }

        public void setRank(int rank) {
            this.Rank = rank;
        }

        public boolean is_destroy() {
            if(this.LifePoint<=0){
                return true;
            }else{
                return false;
            }
        }

        public boolean haveWeaponEquip() {
            if(this.MapEquipedWeapons==null){
                return false;
            }else{
                return true;
            }
        }

        public void addFuel(int NBFUEL) {
            this.fuelMeter+=NBFUEL;
        }

        public int getFuelMeter() {
            return fuelMeter;
        }

        public Storage getMyStorage() {
            return myStorage;
        }

        public Place getMyPlace() {
            return myPlace;
        }

        
        

}