package ToInfinityAndBeyond.SpacialPackage;

import ToInfinityAndBeyond.ZoneIteractionsPackage.*;

public class Storage {

	/**
	 * HashMap
	 */
	private Items ListOfItems;
	private int Capacity;
	private int CapacityMax;

	/**
	 * 
	 * @param thisItem
	 */
	public void addItem(Items thisItem) {
		// TODO - implement Storage.addItem
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisItem
	 */
	public void deleteItem(Items thisItem) {
		// TODO - implement Storage.deleteItem
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param thisItem
	 */
	public void dropItem(Items thisItem) {
		// TODO - implement Storage.dropItem
		throw new UnsupportedOperationException();
	}

}