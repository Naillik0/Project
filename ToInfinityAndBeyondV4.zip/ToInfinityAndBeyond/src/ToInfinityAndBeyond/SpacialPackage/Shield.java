package ToInfinityAndBeyond.SpacialPackage;

public class Shield {

    //CONSTANT
        private final int ENERGYMAX;
    //VARIABLE
	private boolean Actif;
	private int Energy;
	
    //BUILDER
	public Shield(boolean actif,int maxEnergy) {
            this.Actif = actif;
            this.Energy = maxEnergy;
            this.ENERGYMAX=maxEnergy;
	}
    
    //METHOD
	public void ActivateShield() {
            this.Actif=true;
	}

	public void DesactivateShield() {
            this.Actif=false;
	}

	public int getEnergy() {
            return this.Energy;
	}

	public void DecreaseEnergy(int value) {
            this.Energy-=value;
	}

	public void ResetEnergy() {
            this.Energy=ENERGYMAX;
	}

}