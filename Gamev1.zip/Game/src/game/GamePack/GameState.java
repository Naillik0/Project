package Game.GamePack;

public enum GameState {
	Start,
	Selection,
	Option,
	In_game
}