package Game.GamePack;

public enum Action {
	Use,
	Find,
	Move,
	Fly,
	Fight
}