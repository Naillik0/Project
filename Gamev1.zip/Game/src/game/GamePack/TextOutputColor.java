package Game.GamePack;

public class TextOutputColor extends Game {
}