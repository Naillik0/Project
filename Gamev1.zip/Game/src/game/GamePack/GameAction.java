package Game.GamePack;

public enum GameAction {
	Battle,
	Waiting,
	Shop
}