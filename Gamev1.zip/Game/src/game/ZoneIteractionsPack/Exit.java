package Game.ZoneIteractionsPack;

public class Exit {

	private int Distance;

	public Place getOtherPlace() {
            return null;

	}

	public void getDistance() {
		// TODO - implement Exit.getDistance
		throw new UnsupportedOperationException();
	}

}