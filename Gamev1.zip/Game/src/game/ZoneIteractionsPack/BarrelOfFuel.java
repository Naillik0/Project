package Game.ZoneIteractionsPack;

public class BarrelOfFuel extends Items {

	private String NAME;
	private int AmountOfFuel;

	public void Use() {
		// TODO - implement BarrelOfFuel.Use
		throw new UnsupportedOperationException();
	}

}