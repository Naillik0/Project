package Game.ZoneIteractionsPack;

public abstract class Items extends Interaction {

	private String NAME;

	public abstract void Use();

}