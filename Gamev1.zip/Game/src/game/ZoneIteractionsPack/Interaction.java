package Game.ZoneIteractionsPack;

public abstract class Interaction {
}