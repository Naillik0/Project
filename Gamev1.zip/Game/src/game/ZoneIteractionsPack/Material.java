package Game.ZoneIteractionsPack;

public class Material extends Items {

	private String NAME;
	private int Price;

    @Override
    public void Use() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}