package Game.ZoneIteractionsPack;

public class Place {

	private String NAME;

}