package Game.SpaceShipPack;

public class Gatling extends Weapons {

	public Gatling() {
		// TODO - implement Gatling.Gatling
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param other
	 */
	public void useW(SpaceShip other) {
		// TODO - implement Gatling.useW
		throw new UnsupportedOperationException();
	}

}