package Game.SpaceShipPack;

public abstract class Weapons {

	private String TYPE;
	private int DAMAGE;
	private int DELAY;
	private int NumOfHit;
	private int Ammo;

	public Weapons() {
		// TODO - implement Weapons.Weapons
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param other
	 */
	public void useW(SpaceShip other) {
		// TODO - implement Weapons.useW
		throw new UnsupportedOperationException();
	}

	public boolean canShoot() {
		// TODO - implement Weapons.canShoot
		throw new UnsupportedOperationException();
	}

}