package Game.SpaceShipPack;

public class Player extends SpaceShip {

	private int Fuel;

        public Player(String name, int lifepoint) {
            super(name, lifepoint);
        }

	public void setFuel() {
		// TODO - implement Player.setFuel
		throw new UnsupportedOperationException();
	}

	public void getFuel() {
		// TODO - implement Player.getFuel
		throw new UnsupportedOperationException();
	}

	public void addFuel() {
		// TODO - implement Player.addFuel
		throw new UnsupportedOperationException();
	}

}