package Game.SpaceShipPack;

public class Bomb extends Weapons {

	public Bomb() {
		// TODO - implement Bomb.Bomb
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param other
	 */
	public void useW(SpaceShip other) {
		// TODO - implement Bomb.useW
		throw new UnsupportedOperationException();
	}

}