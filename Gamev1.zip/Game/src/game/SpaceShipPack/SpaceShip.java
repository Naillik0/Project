package Game.SpaceShipPack;

import Game.ZoneIteractionsPack.*;

public class SpaceShip extends Interaction {

	private String Name;
	private int LifePoint;
	private int LIFEPOINTMAX;

	/**
	 * 
	 * @param name
	 * @param lifepoint
	 */
	public SpaceShip(String name, int lifepoint) {
		// TODO - implement SpaceShip.SpaceShip
		throw new UnsupportedOperationException();
	}

	public void getHit() {
		// TODO - implement SpaceShip.getHit
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param numWeapon
	 * @param enemi
	 */
	public void UseWeapon(int numWeapon, SpaceShip enemi) {
		// TODO - implement SpaceShip.UseWeapon
		throw new UnsupportedOperationException();
	}

	public boolean is_destroy() {
		// TODO - implement SpaceShip.is_destroy
		throw new UnsupportedOperationException();
	}

}